#!/usr/bin/env bash
# ================================================================
#  JSS Quote Agent -> GitHub  一键上传助手
#
#  用法:
#    bash upload.sh                 # 交互式，自动选公开/私有
#    bash upload.sh --private       # 直接建私有仓库
#    bash upload.sh --public        # 直接建公开仓库
#
#  前提: 本目录是解压后的 jss-quote-agent 文件夹
# ================================================================
set -u

REPO_NAME="jss-quote-agent"
DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "========================================"
echo "  JSS Quote Agent  ->  GitHub"
echo "========================================"
echo ""

# ---------- 1. 检查环境 ----------
if ! command -v git >/dev/null 2>&1; then
  echo "[x] 没找到 git"
  echo "    请先安装：https://git-scm.com/downloads"
  exit 1
fi
echo "[ok] git: $(git --version)"

HAS_GH=0
if command -v gh >/dev/null 2>&1; then
  HAS_GH=1
  echo "[ok] GitHub CLI: $(gh --version | head -1)"
else
  echo "[--] 未安装 GitHub CLI（可稍后安装：https://cli.github.com）"
fi

cd "$DIR"

# ---------- 2. 可见性 ----------
VISIBILITY=""
case "${1:-}" in
  --private) VISIBILITY="private" ;;
  --public)  VISIBILITY="public" ;;
esac

if [ -z "$VISIBILITY" ]; then
  echo ""
  echo "仓库可见性："
  echo "  1) Private  (推荐) -- 含供应商报价与公司全名，仅自己可见"
  echo "  2) Public           -- 所有人可见，建议先脱敏"
  printf "请选择 [1/2]（默认 1）: "
  read -r V
  case "$V" in
    2) VISIBILITY="public" ;;
    *) VISIBILITY="private" ;;
  esac
fi
echo ""
echo ">> 可见性: $VISIBILITY"

# ---------- 3. 提交 ----------
# git 身份兜底：未配置 user.name / user.email 时 git commit 会直接失败，
# 这里用 GitHub 用户名（若已登录）或占位值兜底，不让脚本卡死。
if [ -z "$(git config --get user.email 2>/dev/null)" ] || [ -z "$(git config --get user.name 2>/dev/null)" ]; then
  echo ""
  echo "[*] 未配置 git 身份，自动设置..."
  GIT_NAME=""
  GIT_MAIL=""
  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    GIT_NAME=$(gh api user --jq .name 2>/dev/null)
    GIT_MAIL=$(gh api user --jq .email 2>/dev/null)
  fi
  [ -z "$GIT_NAME" ]  && GIT_NAME="jss-quote-agent"
  [ -z "$GIT_MAIL" ] && GIT_MAIL="jss-quote-agent@users.noreply.github.com"
  git config user.name "$GIT_NAME"
  git config user.email "$GIT_MAIL"
  echo "    user.name  = $GIT_NAME"
  echo "    user.email = $GIT_MAIL"
fi

if [ ! -d .git ]; then
  echo ""
  echo "[1/3] 初始化仓库..."
  git init -b main >/dev/null 2>&1
  git add -A
  git commit -q -m "feat: JSS 电机出口报价 Agent 配置与 jss-quoting 技能包"
  echo "      完成 ($(git ls-files | wc -l) 个文件)"
else
  echo ""
  echo "[1/3] 仓库已初始化，跳过"
fi

# ---------- 4. 建仓推送 ----------
echo ""
echo "[2/3] 登录 GitHub..."
if [ "$HAS_GH" = "1" ]; then
  if ! gh auth status >/dev/null 2>&1; then
    echo "      打开浏览器完成登录..."
    gh auth login --hostname github.com --git-protocol https --web
  fi
  echo "      登录正常"

  echo ""
  echo "[3/3] 创建仓库并推送..."
  if gh repo create "$REPO_NAME" --"$VISIBILITY" --source=. --remote=origin --push 2>&1 | sed 's/^/      /'; then
    URL=$(gh repo view --json url --jq .url 2>/dev/null)
    echo ""
    echo "========================================"
    echo "  完成!"
    echo "  $URL"
    echo "========================================"
    echo ""
    echo "下一步: 把 .git 里的提交历史也带上(可选)"
    exit 0
  fi
  echo "      自动创建失败，通常是仓库名已存在。"
fi

# ---------- 5. 手动方式 ----------
echo ""
echo "改用手动方式："
echo ""
if [ "$HAS_GH" = "1" ]; then
  echo "  gh repo create $REPO_NAME --$VISIBILITY --source=. --remote=origin --push"
fi
echo "  git remote add origin https://github.com/<你的用户名>/$REPO_NAME.git"
echo "  git push -u origin main"
echo ""
echo "或者完全不用命令行 —— 网页上传:"
echo "  1) https://github.com/new  建空仓库(不勾选任何初始化文件)"
echo "  2) Add file -> Upload files"
echo "  3) 把 jss-quote-agent 整个文件夹拖进去"
echo ""
