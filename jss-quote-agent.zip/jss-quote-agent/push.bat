@echo off
chcp 65001 >nul
REM ========================================
REM   JSS Quote Agent -> GitHub
REM ========================================
echo.
echo ========================================
echo   JSS Quote Agent -^> GitHub
echo ========================================
echo.

where git >nul 2>nul
if errorlevel 1 (
  echo [错误] 没找到 git，请先安装：https://git-scm.com/downloads
  pause
  exit /b 1
)

cd /d "%~dp0"

REM git 身份兜底：未配置 user.name / user.email 时 git commit 会失败
for /f "delims=" %%i in ('git config user.email 2^>nul') do set "GITMAIL=%%i"
if not defined GITMAIL (
  echo [*] 未配置 git 身份，自动设置...
  set "GITNAME=jss-quote-agent"
  set "GITMAIL=jss-quote-agent@users.noreply.github.com"
  git config user.name %GITNAME%
  git config user.email %GITMAIL%
)

if not exist ".git" (
  echo [1/4] 初始化 git 仓库...
  git init -b main
  git add -A
  git commit -m "feat: JSS 电机出口报价 Agent 配置与 jss-quoting 技能包"
  echo       已提交
) else (
  echo [1/4] git 仓库已存在，跳过
)

echo.
echo [2/4] 仓库可见性：
echo   1) Private （推荐）-- 含供应商报价和公司全名
echo   2) Public  -- 所有人可见，需先自行脱敏
set /p VIS="请选择 [1/2]（默认 1）: "
if "%VIS%"=="2" (set VISIBILITY=public) else (set VISIBILITY=private)
echo       选择：%VISIBILITY%

echo.
echo [3/4] 检查 GitHub 登录状态...
where gh >nul 2>nul
if errorlevel 1 (
  echo       没装 GitHub CLI。
  echo       请改用网页上传：https://github.com/new
  echo       建空仓库 -^> Add file -^> Upload files，拖入 jss-quote-agent 文件夹
  echo.
  echo       或先装 CLI：https://cli.github.com
  echo.
  echo 已经帮你提交好了，也可以手动推送：
  echo   git remote add origin https://github.com/你的用户名/jss-quote-agent.git
  echo   git push -u origin main
  pause
  exit /b 0
)

gh auth status >nul 2>nul
if errorlevel 1 (
  echo       需要登录，正在打开授权流程...
  gh auth login --hostname github.com --git-protocol https --web
)
echo       登录正常

echo.
echo [4/4] 创建仓库并推送...
gh repo create jss-quote-agent --%VISIBILITY% --source=. --remote=origin --push
if errorlevel 1 (
  echo.
  echo 创建失败（可能仓库名已存在）。改用手动方式：
  echo   git remote add origin https://github.com/你的用户名/jss-quote-agent.git
  echo   git push -u origin main
  pause
  exit /b 1
)

echo.
echo ========================================
echo   完成！
echo ========================================
pause
