#!/usr/bin/env bash
# 一键推送到 GitHub
# 用法: bash push.sh
set -e

REPO_NAME="jss-quote-agent"

echo "========================================"
echo "  JSS Quote Agent -> GitHub"
echo "========================================"
echo ""

# 1. 检查 git
if ! command -v git >/dev/null 2>&1; then
  echo "[错误] 没找到 git，请先安装：https://git-scm.com/downloads"
  exit 1
fi

cd "$(dirname "$0")"

# 2. 初始化并提交
# git 身份兜底：未配置 user.name / user.email 时 git commit 会失败
if [ -z "$(git config --get user.email 2>/dev/null)" ] || [ -z "$(git config --get user.name 2>/dev/null)" ]; then
  echo "      [*] 未配置 git 身份，自动设置..."
  GIT_NAME="jss-quote-agent"
  GIT_MAIL="jss-quote-agent@users.noreply.github.com"
  if command -v gh >/dev/null 2>&1 && gh auth status >/dev/null 2>&1; then
    [ -n "$(gh api user --jq .name 2>/dev/null)" ] && GIT_NAME=$(gh api user --jq .name 2>/dev/null)
    [ -n "$(gh api user --jq .email 2>/dev/null)" ] && GIT_MAIL=$(gh api user --jq .email 2>/dev/null)
  fi
  git config user.name "$GIT_NAME"
  git config user.email "$GIT_MAIL"
fi

if [ ! -d .git ]; then
  echo "[1/4] 初始化 git 仓库..."
  git init -b main
  git add -A
  git commit -q -m "feat: JSS 电机出口报价 Agent 配置与 jss-quoting 技能包"
  echo "      已提交"
else
  echo "[1/4] git 仓库已存在，跳过"
fi

# 3. 选择可见性
echo ""
echo "[2/4] 仓库可见性："
echo "  1) Private （推荐）—— 含供应商报价和公司全名"
echo "  2) Public  —— 所有人可见，需先自行脱敏"
printf "请选择 [1/2]（默认 1）: "
read -r VIS

case "$VIS" in
  2) VISIBILITY="public" ;;
  *) VISIBILITY="private" ;;
esac
echo "      选择：$VISIBILITY"

# 4. 登录
echo ""
echo "[3/4] 检查 GitHub 登录状态..."
if command -v gh >/dev/null 2>&1; then
  if ! gh auth status >/dev/null 2>&1; then
    echo "      需要登录，正在打开授权流程..."
    gh auth login --hostname github.com --git-protocol https --web
  fi
  echo "      登录正常"

  # 5. 建仓推送
  echo ""
  echo "[4/4] 创建仓库并推送..."
  if gh repo create "$REPO_NAME" --"$VISIBILITY" --source=. --remote=origin --push; then
    URL=$(gh repo view --json url --jq .url)
    echo ""
    echo "========================================"
    echo "  完成！"
    echo "  $URL"
    echo "========================================"
  else
    echo "创建失败（可能仓库名已存在）。改用手动方式："
    echo "  git remote add origin https://github.com/<你的用户名>/$REPO_NAME.git"
    echo "  git push -u origin main"
  fi
else
  echo "      没装 GitHub CLI。请改用网页上传："
  echo "      https://github.com/new  ->  建空仓库 -> Add file -> Upload files"
  echo ""
  echo "      或先装 CLI：https://cli.github.com"
  echo ""
  echo "已经帮你提交好了，现在可以："
  echo "  git remote add origin https://github.com/<你的用户名>/$REPO_NAME.git"
  echo "  git push -u origin main"
fi
