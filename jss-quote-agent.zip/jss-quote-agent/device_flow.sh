#!/usr/bin/env bash
# ================================================================
#  设备码方式建仓（GitHub Device Flow）
#
#  原理: 向 GitHub 申请一次性设备码 -> 用户在浏览器输入 user_code
#        -> 轮询换取 access_token -> 建仓推送
#
#  设备码有效期 15 分钟，过期会自动续签换新码。
#
#  用法: bash device_flow.sh [--private|--public]
#        脚本运行后按提示在浏览器输入显示的码即可
# ================================================================
set -u

REPO_NAME="jss-quote-agent"
DIR="$(cd "$(dirname "$0")" && pwd)"
CLIENT_ID="Iv1.b507a08c87ecfe98"
VISIBILITY="private"
case "${1:-}" in
  --private) VISIBILITY="private" ;;
  --public)  VISIBILITY="public" ;;
esac

cd "$DIR"

# ---------- 环境检查 ----------
if ! command -v curl >/dev/null 2>&1; then
  echo "[x] 需要 curl，请先安装"
  exit 1
fi
if ! command -v gh >/dev/null 2>&1; then
  echo "[x] 需要 GitHub CLI：https://cli.github.com"
  exit 1
fi

# ---------- 提交 ----------
# git 身份兜底：未配置 user.name / user.email 时 git commit 会失败
if [ -z "$(git config --get user.email 2>/dev/null)" ] || [ -z "$(git config --get user.name 2>/dev/null)" ]; then
  GIT_NAME="jss-quote-agent"
  GIT_MAIL="jss-quote-agent@users.noreply.github.com"
  if gh auth status >/dev/null 2>&1; then
    [ -n "$(gh api user --jq .name 2>/dev/null)" ] && GIT_NAME=$(gh api user --jq .name 2>/dev/null)
    [ -n "$(gh api user --jq .email 2>/dev/null)" ] && GIT_MAIL=$(gh api user --jq .email 2>/dev/null)
  fi
  git config user.name "$GIT_NAME"
  git config user.email "$GIT_MAIL"
  echo "[*] 未配置 git 身份，已自动设置: $GIT_NAME <$GIT_MAIL>"
fi

if [ ! -d .git ]; then
  git init -b main >/dev/null 2>&1
  git add -A
  git commit -q -m "feat: JSS 电机出口报价 Agent 配置与 jss-quoting 技能包"
fi

USER_CODE=""
DEVICE_CODE=""

issue_code() {
  local resp
  resp=$(curl -s -X POST -H "Accept: application/json" https://github.com/login/device/code \
    -d client_id="$CLIENT_ID" -d scope="repo read:org gist")
  DEVICE_CODE=$(printf '%s' "$resp" | sed -n 's/.*"device_code":"\([^"]*\)".*/\1/p')
  USER_CODE=$(printf '%s' "$resp" | sed -n 's/.*"user_code":"\([^"]*\)".*/\1/p')
  [ -n "$DEVICE_CODE" ] && [ -n "$USER_CODE" ]
}

echo ""
echo "========================================"
echo "  GitHub 设备码授权"
echo "========================================"
echo ""

if ! issue_code; then
  echo "[x] 申请设备码失败，检查网络"
  exit 1
fi

echo "  请打开：https://github.com/login/device"
echo "  输入码：$USER_CODE"
echo ""
echo "  (码 15 分钟有效，过期会自动换新)"
echo ""

TOKEN=""
while [ -z "$TOKEN" ]; do
  resp=$(curl -s -X POST -H "Accept: application/json" https://github.com/login/oauth/access_token \
    -d client_id="$CLIENT_ID" -d device_code="$DEVICE_CODE" \
    -d grant_type=urn:ietf:params:oauth:grant-type:device_code)
  case "$resp" in
    *access_token*)
      TOKEN=$(printf '%s' "$resp" | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p')
      ;;
    *expired_token*)
      issue_code
      echo "  [码已过期] 请输入新码：$USER_CODE"
      echo ""
      ;;
    *slow_down*) sleep 10 ;;
    *authorization_pending*) ;;
    *) echo "[x] 授权失败: $resp"; exit 1 ;;
  esac
  [ -z "$TOKEN" ] && sleep 5
done

echo ""
echo "[ok] 授权成功"

mkdir -p "$HOME/.config/gh"
printf '{"hosts":{"github.com":{"oauth_token":"%s"}}}' "$TOKEN" > "$HOME/.config/gh/hosts.yml"
chmod 600 "$HOME/.config/gh/hosts.yml"

LOGIN=$(gh api user --jq .login)
echo "[ok] 账号: $LOGIN"

git remote remove origin 2>/dev/null
git remote add origin "https://github.com/$LOGIN/$REPO_NAME.git"

if gh repo create "$LOGIN/$REPO_NAME" --"$VISIBILITY" --source=. --remote=origin --push >/dev/null 2>&1; then
  echo ""
  echo "========================================"
  echo "  完成!  https://github.com/$LOGIN/$REPO_NAME"
  echo "========================================"
else
  git push -u origin main >/dev/null 2>&1 && {
    echo ""
    echo "========================================"
    echo "  完成!  https://github.com/$LOGIN/$REPO_NAME"
    echo "========================================"
  } || {
    echo "[x] 推送失败，请检查仓库名是否已被占用"
    exit 1
  }
fi
