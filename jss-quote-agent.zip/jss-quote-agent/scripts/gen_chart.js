// 闭环电机转速-转矩曲线图（比开环大10%）
const fs = require('fs');

// 闭环数据 = 开环 × 1.10
const data = [
  [0, 55], [50, 54], [100, 52], [150, 48], [200, 44],
  [250, 39], [300, 32], [350, 25], [400, 19], [450, 13], [500, 9]
];

const width = 500, height = 350;
const padding = { top: 30, right: 30, bottom: 50, left: 60 };
const plotW = width - padding.left - padding.right;
const plotH = height - padding.top - padding.bottom;

const xMax = 500, yMax = 60;

function tx(v) { return padding.left + (v / xMax) * plotW; }
function ty(v) { return padding.top + plotH - (v / yMax) * plotH; }

let path = '';
data.forEach(([x, y], i) => {
  const px = tx(x), py = ty(y);
  path += (i === 0 ? 'M' : 'L') + px + ',' + py;
});

let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
<rect width="${width}" height="${height}" fill="white"/>
`;

for (let i = 0; i <= 5; i++) {
  const y = padding.top + (i / 5) * plotH;
  const val = Math.round(yMax - (i / 5) * yMax);
  svg += `<line x1="${padding.left}" y1="${y}" x2="${padding.left + plotW}" y2="${y}" stroke="#e0e0e0"/>`;
  svg += `<text x="${padding.left - 8}" y="${y + 4}" font-family="Arial" font-size="11" text-anchor="end" fill="#333">${val}</text>`;
}
for (let i = 0; i <= 5; i++) {
  const x = padding.left + (i / 5) * plotW;
  const val = Math.round((i / 5) * xMax);
  svg += `<line x1="${x}" y1="${padding.top}" x2="${x}" y2="${padding.top + plotH}" stroke="#e0e0e0"/>`;
  svg += `<text x="${x}" y="${padding.top + plotH + 16}" font-family="Arial" font-size="11" text-anchor="middle" fill="#333">${val}</text>`;
}

svg += `<line x1="${padding.left}" y1="${padding.top}" x2="${padding.left}" y2="${padding.top + plotH}" stroke="#333" stroke-width="1.5"/>`;
svg += `<line x1="${padding.left}" y1="${padding.top + plotH}" x2="${padding.left + plotW}" y2="${padding.top + plotH}" stroke="#333" stroke-width="1.5"/>`;

svg += `<path d="${path}" stroke="#4472C4" stroke-width="2.5" fill="none"/>`;

data.forEach(([x, y]) => {
  svg += `<circle cx="${tx(x)}" cy="${ty(y)}" r="3" fill="#4472C4"/>`;
});

svg += `<text x="${padding.left + plotW / 2}" y="${height - 15}" font-family="Arial" font-size="12" text-anchor="middle" fill="#333">转速 (rpm)</text>`;
svg += `<text x="${20}" y="${padding.top + plotH / 2}" font-family="Arial" font-size="12" text-anchor="middle" fill="#333" transform="rotate(-90 20 ${padding.top + plotH / 2})">转矩 (N.m)</text>`;

svg += '</svg>';

fs.writeFileSync('curve_chart.svg', svg);

const sharp = require('sharp');
sharp(Buffer.from(svg))
  .png()
  .toFile('curve_chart.png')
  .then(() => console.log('PNG generated (closed-loop)'));
