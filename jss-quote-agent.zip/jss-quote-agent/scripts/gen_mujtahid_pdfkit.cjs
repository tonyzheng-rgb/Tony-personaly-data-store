// English quotation for MujtahidCNC (Jordan) - 3HSS2206 sets - using PDFKit
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const out = path.resolve('JSS-20261015-MujtahidCNC-3HSS2206-Quotation.pdf');
const doc = new PDFDocument({ size: 'A4', margin: 30, info: { Title: 'Quotation JSS-20261015-MujtahidCNC', Author: 'JSS Motor' } });
doc.pipe(fs.createWriteStream(out));

// Color palette
const NAVY = '#1F4E79';
const LIGHT_BLUE = '#E8F0F8';
const YELLOW = '#FFF8E1';
const ORANGE = '#FFB300';
const RED = '#D32F2F';
const GREEN = '#388E3C';
const GRAY = '#999999';
const TEXT = '#000000';

// ============ HEADER ============
const pageW = doc.page.width - 60;

// Logo
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(28).text('JSS-MOTOR', 30, 30);
doc.fillColor('#666666').font('Helvetica').fontSize(8).text('JINSHISHI Motor · Changzhou', 30, 62);

// Company info (right)
const rX = 350;
doc.fillColor(TEXT).font('Helvetica-Bold').fontSize(9).text('Changzhou JSS Motor Co., Ltd.', rX, 32, { width: pageW - 320, align: 'right' });
doc.font('Helvetica').fontSize(8).fillColor('#444444');
[
  'No. 168, Changzhou Industrial Park,',
  'Jiangsu, China',
  'Tel: +86 519-8888-XXXX',
  'E-mail: sales@jss-motor.com',
  'Website: www.jss-motor.com'
].forEach((t, i) => doc.text(t, rX, 45 + i * 10, { width: pageW - 320, align: 'right' }));

// Divider
doc.moveTo(30, 95).lineTo(doc.page.width - 30, 95).lineWidth(2).strokeColor(NAVY).stroke();

// Title
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(22).text('QUOTATION', 30, 105, { align: 'center', width: pageW });

// Quote info row
const infoY = 145;
doc.font('Helvetica').fontSize(9).fillColor(TEXT);
doc.text('Quotation No.:', 30, infoY);
doc.font('Helvetica-Bold').fillColor(NAVY).text('JSS-20261015-MujtahidCNC-001', 100, infoY);
doc.font('Helvetica').fillColor(TEXT).text('Date:', 270, infoY);
doc.font('Helvetica-Bold').text('2026-10-15', 295, infoY);
doc.font('Helvetica').text('Valid Until:', 380, infoY);
doc.font('Helvetica-Bold').text('2026-11-14', 430, infoY);

// ============ BIDDER BLOCKS ============
const bidY = 170;
const blockW = (pageW - 10) / 2;

// LEFT - From
doc.rect(30, bidY, blockW, 95).fillAndStroke('#F5F8FC', '#333333');
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(10).text('FROM (Quoter)', 35, bidY + 5);
doc.strokeColor(NAVY).lineWidth(0.5).moveTo(35, bidY + 18).lineTo(blockW + 25, bidY + 18).stroke();
doc.fillColor(TEXT).font('Helvetica').fontSize(8);
const fromLines = [
  ['Company:', 'Changzhou JSS Motor Co., Ltd.'],
  ['Contact:', 'Sales Dept. - Tony'],
  ['Tel:', '+86 138-XXXX-XXXX'],
  ['E-mail:', 'sales@jss-motor.com']
];
fromLines.forEach((l, i) => {
  doc.font('Helvetica-Bold').fillColor('#555').text(l[0], 35, bidY + 24 + i * 14);
  doc.font('Helvetica').fillColor(TEXT).text(l[1], 90, bidY + 24 + i * 14);
});

// RIGHT - To
const toX = 30 + blockW + 10;
doc.rect(toX, bidY, blockW, 95).fillAndStroke('#F5F8FC', '#333333');
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(10).text('TO (Inquirer)', toX + 5, bidY + 5);
doc.strokeColor(NAVY).lineWidth(0.5).moveTo(toX + 5, bidY + 18).lineTo(toX + blockW - 5, bidY + 18).stroke();
doc.fillColor(TEXT).font('Helvetica').fontSize(8);
const toLines = [
  ['Company:', 'MujtahidCNC'],
  ['Contact:', 'Eng. Amin Fahmi Ali Othman'],
  ['Tel/WhatsApp:', '+962 78 2981260'],
  ['E-mail:', 'ameenfahmi@gmail.com'],
  ['Country:', 'Jordan · Self Use']
];
toLines.forEach((l, i) => {
  doc.font('Helvetica-Bold').fillColor('#555').text(l[0], toX + 5, bidY + 24 + i * 12);
  doc.font('Helvetica').fillColor(TEXT).text(l[1], toX + 75, bidY + 24 + i * 12);
});

// ============ TABLE ============
const tblY = 285;
const cols = [
  { label: 'No.', w: 25, align: 'center' },
  { label: 'Model', w: 110, align: 'left' },
  { label: 'Description', w: 220, align: 'left' },
  { label: 'Qty', w: 35, align: 'center' },
  { label: 'Unit (USD)', w: 55, align: 'right' },
  { label: 'Total (USD)', w: 65, align: 'right' }
];

// Header
let x = 30;
cols.forEach(c => {
  doc.rect(x, tblY, c.w, 22).fillAndStroke(NAVY, '#000');
  doc.fillColor('#FFF').font('Helvetica-Bold').fontSize(9).text(c.label, x, tblY + 6, { width: c.w, align: c.align });
  x += c.w;
});

// Rows
const rows = [
  ['1', '3HSS2206+110HCE12N-B39+3M', '3-Phase 220V AC Hybrid Servo Set: 6A Driver + 110 Frame 12N·m Closed-Loop Stepper + 3m Cable (B39 brake type)', '1 set', '$185.52', '$185.52'],
  ['2', '3HSS2206+110HCE16N-B39+3M', '3-Phase 220V AC Hybrid Servo Set: 6A Driver + 110 Frame 16N·m Closed-Loop Stepper + 3m Cable', '1 set', '$201.94', '$201.94'],
  ['3', '3HSS2206+110HCE20N-B39+3M', '3-Phase 220V AC Hybrid Servo Set: 6A Driver + 110 Frame 20N·m Closed-Loop Stepper + 3m Cable', '1 set', '$215.07', '$215.07']
];

let ry = tblY + 22;
rows.forEach((r, i) => {
  x = 30;
  const rowH = 32;
  doc.rect(x, ry, cols.reduce((s,c)=>s+c.w,0), rowH).stroke('#333');
  cols.forEach((c, j) => {
    doc.fillColor(TEXT).font('Helvetica').fontSize(8).text(String(r[j]), x + 3, ry + 4, { width: c.w - 6, align: c.align });
    x += c.w;
  });
  ry += rowH;
});

// Total row
x = 30;
const totalW = cols.reduce((s,c)=>s+c.w,0);
doc.rect(x, ry, totalW, 22).fillAndStroke(LIGHT_BLUE, '#333');
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(9).text('EXW Yiwu · USD Subtotal (per set):', 30 + 3, ry + 6, { width: totalW - 130, align: 'right' });
doc.fillColor(NAVY).text('$185.52 – $215.07', 30 + totalW - 125, ry + 6, { width: 120, align: 'right' });

// ============ NOTE BOX ============
const noteY = ry + 35;
const noteH = 80;
doc.rect(30, noteY, pageW, noteH).fillAndStroke(YELLOW, ORANGE);
doc.lineWidth(3).moveTo(30, noteY).lineTo(30, noteY + noteH).strokeColor(ORANGE).stroke();
doc.fillColor(ORANGE).font('Helvetica-Bold').fontSize(10).text('📌 Note on "3HSS2260" model', 40, noteY + 6);
doc.fillColor(TEXT).font('Helvetica').fontSize(8.5);
doc.text('Thank you for your inquiry, Eng. Amin. Our standard AC hybrid servo set is 3HSS2206 (3-phase 220V, 6A) paired with 110-frame closed-loop stepper motors (12N·m / 16N·m / 20N·m). All prices include 3m cable and 1 year warranty.\n\nIf you require a higher-current driver (e.g., 60A for 130-frame NEMA 34 motors), please confirm the torque / speed / application and we will quote separately.', 40, noteY + 22, { width: pageW - 20 });

// ============ TERMS ============
const termY = noteY + noteH + 15;
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(11).text('Terms & Conditions', 30, termY);
const terms = [
  '1. Price Term: EXW Yiwu, China. (FOB Ningbo / CIF Aqaba available on request.)',
  '2. Payment: 30% T/T deposit upon order confirmation, 70% balance before shipment.',
  '3. Lead Time: 5-7 working days for in-stock items after deposit received.',
  '4. Warranty: 12 months for drivers & motors; 3-6 months for bearings.',
  '5. Validity: This quotation is valid for 30 days from the date above.',
  '6. Packing: Standard export carton with foam protection.',
  '7. Shipping to Jordan: Sea freight Yiwu → Aqaba approx. 25-30 days (CIF on request).'
];
doc.fillColor(TEXT).font('Helvetica').fontSize(8.5);
terms.forEach((t, i) => doc.text(t, 30, termY + 18 + i * 11, { width: pageW }));

// ============ TORQUE-SPEED CURVE ============
const curveY = termY + 18 + terms.length * 11 + 15;
doc.fillColor(NAVY).font('Helvetica-Bold').fontSize(11).text('Torque-Speed Reference (110HCE Closed-Loop, +10% over open-loop)', 30, curveY);
doc.fillColor('#555').font('Helvetica').fontSize(8).text('Note: Closed-loop stepper theoretical torque output is approximately 10% higher than equivalent open-loop stepper.', 30, curveY + 14);

// Curve chart area
const cX = 50, cY = curveY + 30, cW = pageW - 40, cH = 160;
doc.rect(cX, cY, cW, cH).fillAndStroke('#F9F9F9', '#333');

// Y axis labels (torque 0-25)
for (let t = 0; t <= 25; t += 5) {
  const yy = cY + cH - (t / 25) * cH;
  doc.fillColor('#333').font('Helvetica').fontSize(7).text(String(t), cX - 18, yy - 3, { width: 15, align: 'right' });
  if (t > 0) doc.lineWidth(0.3).strokeColor('#DDD').moveTo(cX, yy).lineTo(cX + cW, yy).stroke();
}

// X axis labels (speed 0-2500)
for (let s = 0; s <= 2500; s += 500) {
  const xx = cX + (s / 2500) * cW;
  doc.fillColor('#333').font('Helvetica').fontSize(7).text(String(s), xx - 12, cY + cH + 4, { width: 24, align: 'center' });
}

// Axis labels
doc.fillColor('#333').font('Helvetica').fontSize(8).text('Torque (N·m)', cX - 35, cY + cH/2 - 10, { width: 30, align: 'center' });
doc.fillColor('#333').font('Helvetica').fontSize(8).text('Speed (RPM)', cX + cW/2 - 30, cY + cH + 18, { width: 60, align: 'center' });

// Curves
// 12N closed loop: 0=13.2, 500=12.5, 1000=11.5, 1500=10, 2000=8, 2500=6.5
function plotCurve(pts, color, dash) {
  doc.strokeColor(color).lineWidth(2);
  if (dash) doc.dash(dash, { space: 3 });
  for (let i = 0; i < pts.length - 1; i++) {
    const x1 = cX + (pts[i][0] / 2500) * cW;
    const y1 = cY + cH - (pts[i][1] / 25) * cH;
    const x2 = cX + (pts[i+1][0] / 2500) * cW;
    const y2 = cY + cH - (pts[i+1][1] / 25) * cH;
    doc.moveTo(x1, y1).lineTo(x2, y2);
  }
  doc.stroke();
  doc.undash();
}

plotCurve([[0, 13.2], [500, 12.5], [1000, 11.5], [1500, 10], [2000, 8], [2500, 6.5]], NAVY, null);
plotCurve([[0, 17.6], [500, 16.7], [1000, 15.4], [1500, 13.4], [2000, 10.7], [2500, 8.7]], RED, [5, 3]);
plotCurve([[0, 22], [500, 20.9], [1000, 19.3], [1500, 16.8], [2000, 13.4], [2500, 10.9]], GREEN, [5, 3]);

// Legend
const lX = cX + cW - 130, lY = cY + 8;
doc.rect(lX, lY, 125, 50).fillAndStroke('#FFFFFF', '#333');
doc.lineWidth(2).strokeColor(NAVY).moveTo(lX + 6, lY + 13).lineTo(lX + 22, lY + 13).stroke();
doc.fillColor(TEXT).font('Helvetica').fontSize(7).text('110HCE12N (12N·m)', lX + 26, lY + 9);
doc.lineWidth(2).strokeColor(RED).dash([5, 3], { space: 3 }).moveTo(lX + 6, lY + 27).lineTo(lX + 22, lY + 27).stroke().undash();
doc.fillColor(TEXT).font('Helvetica').fontSize(7).text('110HCE16N (16N·m)', lX + 26, lY + 23);
doc.lineWidth(2).strokeColor(GREEN).dash([5, 3], { space: 3 }).moveTo(lX + 6, lY + 41).lineTo(lX + 22, lY + 41).stroke().undash();
doc.fillColor(TEXT).font('Helvetica').fontSize(7).text('110HCE20N (20N·m)', lX + 26, lY + 37);

// ============ FOOTER ============
const fY = doc.page.height - 50;
doc.strokeColor(GRAY).lineWidth(0.5).moveTo(30, fY - 5).lineTo(doc.page.width - 30, fY - 5).stroke();
doc.fillColor('#666').font('Helvetica').fontSize(8).text('JSS Motor · Changzhou JSS Motor Co., Ltd. · www.jss-motor.com', 30, fY, { align: 'center', width: pageW });
doc.fillColor(NAVY).font('Helvetica-Oblique').fontSize(9).text('Thank you for your inquiry. We look forward to your confirmation.', 30, fY + 12, { align: 'center', width: pageW });

doc.end();

doc.on('end', () => {
  console.log('PDF generated:', out);
  console.log('Size:', (fs.statSync(out).size / 1024).toFixed(1), 'KB');
});
