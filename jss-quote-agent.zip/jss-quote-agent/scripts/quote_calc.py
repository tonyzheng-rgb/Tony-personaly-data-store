rate = 7.2
tax = 1.10

nema34_unit = 450
nema24_unit = 260
hgr20_per_m = 68
sfu12_per_m = 55
sfu12_nut = 45
sfu16_per_m = 55
sfu16_nut = 50

def proc(L):
    if L <= 1.0: return 20
    elif L <= 2.0: return 30
    elif L <= 3.0: return 50
    elif L <= 4.0: return 70
    else: return 0

items = []
items.append(('NEMA 34 Closed Loop Set 8NM (86HSE8N+HSS86 3M)', nema34_unit, 8))
items.append(('NEMA 24 Closed Loop Set 3.5NM (60HSE3N+HSS57 2M)', nema24_unit, 4))

rails = [('HGR20-250mm cut', 0.25, 2),
         ('HGR20-600mm cut', 0.6, 4),
         ('HGR20-2000mm cut', 2.0, 6),
         ('HGR20-1500mm cut', 1.5, 4),
         ('HGR20-250mm cut', 0.25, 2)]
for n, L, q in rails:
    items.append((n, hgr20_per_m*L, q))

screws = [('SFU1204-280mm', 'S12', 0.28, 2),
          ('SFU1610-600mm', 'S16', 0.6, 2),
          ('SFU1610-580mm', 'S16', 0.58, 2)]
for n, k, L, q in screws:
    pm = sfu12_per_m if k == 'S12' else sfu16_per_m
    nu = sfu12_nut if k == 'S12' else sfu16_nut
    items.append((n + ' (screw+process+nut)', pm*L + proc(L) + nu, q))

print('%-55s %10s %6s %10s' % ('Description', 'Unit(RMB)', 'Qty', 'Subtotal'))
print('-' * 85)
total = 0
for n, u, q in items:
    s = u * q
    total += s
    print('%-55s %10.2f %6d %10.2f' % (n, u, q, s))
print('-' * 85)
print('TOTAL (before tax) RMB: %10.2f' % total)
print('TOTAL (with 10%% tax) RMB: %10.2f' % (total * tax))
print('TOTAL (before tax) USD @7.2: %10.2f' % (total / rate))
print('TOTAL (with tax) USD @7.2: %10.2f' % (total * tax / rate))