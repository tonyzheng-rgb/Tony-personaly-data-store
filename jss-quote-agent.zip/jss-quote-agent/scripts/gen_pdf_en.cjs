// 英文报价单 - 翰祺9kW/12kW风冷ATC主轴，美金报价
const fs = require('fs');
const puppeteer = require('puppeteer');
const path = require('path');

const exchangeRate = 6.7;
// 用户指定的人民币价格（实际是含税人民币价）
const priceRMB = [12000, 13500];
const products = [
  {
    no: 1,
    model: 'GDL70-24Z/9.0',
    desc: '9kW Air-Cooled Automatic Tool Change (ATC) Spindle Motor, ISO30, 4 Bearings (Chinese Brand), 18,000 rpm',
    qty: 1,
    priceRMB: priceRMB[0],
    unitUSD: priceRMB[0] / exchangeRate,
  },
  {
    no: 2,
    model: 'TBD / Custom Order',
    desc: '12kW Air-Cooled Automatic Tool Change (ATC) Spindle Motor, ISO30, 4 Bearings (Chinese Brand), 18,000 rpm',
    qty: 1,
    priceRMB: priceRMB[1],
    unitUSD: priceRMB[1] / exchangeRate,
  },
];

const totalUSD = products.reduce((s, p) => s + p.unitUSD * p.qty, 0);
const totalRMB = totalUSD * exchangeRate;

const productRows = products.map(p => `
  <tr>
    <td class="center">${p.no}</td>
    <td>${p.model}</td>
    <td>${p.desc}</td>
    <td class="center">${p.qty} pc</td>
    <td class="right">
      $${p.unitUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}<br>
      <span style="color:#666;font-size:9px">(¥${p.priceRMB.toLocaleString('en-US')})</span>
    </td>
    <td class="right">
      $${(p.unitUSD * p.qty).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}<br>
      <span style="color:#666;font-size:9px">(¥${(p.priceRMB * p.qty).toLocaleString('en-US')})</span>
    </td>
  </tr>
`).join('');

const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation - Saeed Bright Company</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: Arial, sans-serif; color: #000; padding: 22px; font-size: 11px; }
  .header { background: #1F4E79; color: white; text-align: center; padding: 14px; font-size: 18px; font-weight: bold; letter-spacing: 1px; }
  .subtitle { text-align: center; color: #555; font-style: italic; padding: 6px; font-size: 9px; }
  .title-main { text-align: center; color: #1F4E79; font-size: 26px; font-weight: bold; padding: 12px 0 6px; letter-spacing: 2px; }
  .meta { padding: 4px 0; font-size: 10px; display: flex; justify-content: space-between; }
  .party-block { display: flex; margin-top: 14px; gap: 8px; }
  .party { flex: 1; }
  .party-title { background: #1F4E79; color: white; padding: 7px 12px; font-weight: bold; font-size: 11px; }
  .party-content { border: 1px solid #000; border-top: none; padding: 8px 12px; min-height: 145px; line-height: 1.7; font-size: 10px; }
  table { width: 100%; border-collapse: collapse; margin-top: 14px; }
  table.products th { background: #4472C4; color: white; padding: 9px 4px; font-size: 10px; border: 1px solid #000; text-align: center; font-weight: bold; }
  table.products td { padding: 10px 8px; border: 1px solid #000; font-size: 10px; vertical-align: middle; }
  .center { text-align: center; }
  .right { text-align: right; }
  .total-row { background: #FFF2CC; font-weight: bold; }
  .total-row td { font-size: 12px; padding: 10px; }
  .amount-words { padding: 8px 12px; background: #F8F9FA; border: 1px solid #000; border-top: none; font-size: 10px; }
  .terms-title { background: #1F4E79; color: white; padding: 8px 12px; font-weight: bold; margin-top: 16px; font-size: 11px; }
  .terms { padding: 8px 12px; line-height: 1.9; font-size: 10px; border: 1px solid #000; border-top: none; }
  .footer { text-align: center; color: #555; font-style: italic; padding: 16px 0 4px; font-size: 10px; }
  .signature { margin-top: 20px; text-align: right; font-size: 10px; }
</style>
</head>
<body>
<div class="header">CHANGZHOU JSS MOTOR CO., LTD.</div>
<div class="subtitle">Professional Manufacturer of CNC Spindle Motors, Servo Motors & Stepper Motors  |  www.jss-motor.com  |  info@jss-motor.com</div>

<div class="title-main">QUOTATION</div>

<div class="meta">
  <div><b>Quotation No.:</b> JSS-20261013-SA003 &nbsp;&nbsp;&nbsp; <b>Date:</b> October 13, 2026</div>
  <div><b>Valid Until:</b> November 02, 2026 &nbsp;&nbsp;&nbsp; <b>Currency:</b> USD</div>
</div>

<div class="party-block">
  <div class="party">
    <div class="party-title">FROM (Supplier)</div>
    <div class="party-content">
      <b>Company:</b> Changzhou JSS Motor Co., Ltd.<br>
      <b>Address:</b> Changzhou, Jiangsu, China<br>
      <b>Contact:</b> Sales Department<br>
      <b>Tel:</b> +86-xxx-xxxx-xxxx<br>
      <b>Email:</b> info@jss-motor.com
    </div>
  </div>
  <div class="party">
    <div class="party-title">TO (Customer)</div>
    <div class="party-content">
      <b>Company:</b> Saeed Bright Company<br>
      <b>Address:</b> Afghanistan, Kabul<br>
      <b>Ship To:</b> Yiwu City, China<br>
      <b>Contact Person:</b> Samiullah Samim<br>
      <b>Tel:</b> 93798289276<br>
      <b>Email:</b> samiullahsamim735@gmail.com
    </div>
  </div>
</div>

<table class="products">
  <thead>
    <tr>
      <th style="width:5%">NO.</th>
      <th style="width:18%">Model</th>
      <th style="width:42%">Description</th>
      <th style="width:8%">Qty</th>
      <th style="width:13%">Unit Price (USD)</th>
      <th style="width:14%">Total (USD)</th>
    </tr>
  </thead>
  <tbody>
    ${productRows}
    <tr class="total-row">
      <td colspan="5" class="right" style="padding-right:16px">GRAND TOTAL (USD):</td>
      <td class="right">$${totalUSD.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
    </tr>
    <tr class="total-row">
      <td colspan="5" class="right" style="padding-right:16px">GRAND TOTAL (RMB @ ${exchangeRate}):</td>
      <td class="right">¥${totalRMB.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
    </tr>
  </tbody>
</table>

<div class="terms-title">TERMS & CONDITIONS</div>
<div class="terms">
  1. <b>Price Term:</b> EXW Yiwu, China (FOB Ningbo available upon request).<br>
  2. <b>Payment Term:</b> 30% T/T deposit, 70% balance before shipment.<br>
  3. <b>Delivery Time:</b> 9kW in stock (5-7 days); 12kW custom order (25-30 working days after deposit).<br>
  4. <b>Validity:</b> 20 days from the date of this quotation.<br>
  5. <b>Warranty:</b> 12 months for the spindle motor; bearings excluded.<br>
  6. <b>Packing:</b> Standard export carton with foam protection.<br>
  7. <b>Bearings:</b> Chinese-brand bearings (7-series domestic, Yuzhou/Leitte). NSK imported bearings available at additional cost.<br>
  8. <b>Spindle Type:</b> Air-Cooled Automatic Tool Change (ATC), ISO30 tool holder, 4 bearings, rated speed 18,000 rpm.
</div>

<div class="signature">
  <b>Authorized by:</b> _________________________________<br>
  <b>Sales Department</b><br>
  <b>Date:</b> October 13, 2026
</div>

<div class="footer">
  We look forward to your favorable reply. Thank you for your interest in our products.<br>
  <span style="font-size:9px; color:#888;">CHANGZHOU JSS MOTOR CO., LTD. &nbsp; | &nbsp; Page 1 of 1</span>
</div>
</body>
</html>
`;

const tmpHtml = path.join(require('os').tmpdir(), 'atc_quote_en.html');
fs.writeFileSync(tmpHtml, html, 'utf8');

const outPath = 'C:\\Users\\Administrator\\Coze\\Drive\\扣子\\Saeed_Bright_ATC_Quotation_EN_20261013.pdf';

(async () => {
  try {
    const browser = await puppeteer.launch({
      headless: 'new',
      executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.goto('file:///' + tmpHtml.replace(/\\/g, '/'), { waitUntil: 'networkidle0' });
    await page.pdf({
      path: outPath,
      format: 'A4',
      landscape: true,
      printBackground: true,
      margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' }
    });
    await browser.close();
    if (fs.existsSync(outPath)) {
      const size = fs.statSync(outPath).size;
      console.log('PDF saved:', outPath, '(' + size + ' bytes)');
      console.log('Total USD:', totalUSD);
      console.log('Total RMB @ 6.7:', totalRMB.toFixed(2));
    } else {
      console.error('PDF NOT created');
    }
  } catch (e) {
    console.error('Error:', e.message);
  }
})();
