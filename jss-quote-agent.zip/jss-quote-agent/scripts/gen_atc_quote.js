// 翰祺9kW+12kW风冷自动换刀主轴 报价单 - MIA格式（中文标题+英文客户信息）
const ExcelJS = require('exceljs');

async function main() {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('报价单');

  // 列宽（A-F, 共6列）
  ws.columns = [
    { width: 8 },    // A 序号
    { width: 28 },   // B 我司规格型号
    { width: 36 },   // C 产品名称/描述
    { width: 10 },   // D 数量
    { width: 14 },   // E 单价
    { width: 16 },   // F 备注
  ];

  const thin = { style: 'thin', color: { argb: 'FF000000' } };
  const allBorders = { top: thin, left: thin, bottom: thin, right: thin };
  const centerMid = { horizontal: 'center', vertical: 'middle' };
  const leftMid = { horizontal: 'left', vertical: 'middle', wrapText: true, indent: 1 };
  const rightMid = { horizontal: 'right', vertical: 'middle' };

  // ============ 标题 ============
  ws.mergeCells('A1:F1');
  ws.getCell('A1').value = '工业品报价单 / Industrial Quotation';
  ws.getCell('A1').font = { name: '宋体', size: 18, bold: true };
  ws.getCell('A1').alignment = centerMid;
  ws.getRow(1).height = 36;

  // ============ 报单编号 + 时间 ============
  ws.getCell('A2').value = '报单编号 / Quotation No.:';
  ws.getCell('A2').font = { name: '宋体', size: 10, bold: true };
  ws.getCell('A2').alignment = leftMid;
  ws.mergeCells('B2:D2');
  ws.getCell('B2').value = 'JSS-20261013-SA002';
  ws.getCell('B2').font = { name: '宋体', size: 10, bold: true, color: { argb: 'FFC00000' } };
  ws.getCell('B2').alignment = leftMid;

  ws.getCell('E2').value = '日期 / Date:';
  ws.getCell('E2').font = { name: '宋体', size: 10, bold: true };
  ws.getCell('E2').alignment = rightMid;
  ws.getCell('F2').value = '2026/10/13';
  ws.getCell('F2').font = { name: '宋体', size: 10 };
  ws.getCell('F2').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
  ws.getRow(2).height = 22;

  // ============ 报价方 / 询价方 分栏 ============
  // 标题行
  ws.mergeCells('A3:C3');
  ws.getCell('A3').value = '报价方 / Supplier';
  ws.getCell('A3').font = { name: '宋体', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('A3').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell('A3').alignment = leftMid;
  ws.getCell('A3').border = allBorders;

  ws.mergeCells('D3:F3');
  ws.getCell('D3').value = '询价方 / Customer';
  ws.getCell('D3').font = { name: '宋体', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('D3').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell('D3').alignment = leftMid;
  ws.getCell('D3').border = allBorders;
  ws.getRow(3).height = 22;

  // 报价方信息
  const supplierInfo = [
    '公司 / Company: 常州市金三士机电有限公司',
    'Changzhou JSS Motor Co., Ltd.',
    '地址 / Add: 江苏省常州市',
    '电话 / Tel: +86-xxx-xxxx-xxxx',
    '邮箱 / Email: info@jss-motor.com',
  ];
  // 询价方信息
  const customerInfo = [
    'Company: Saeed Bright Company',
    'Address: Afghanistan, Kabul',
    'Ship To: Yiwu City, China',
    'Contact: Samiullah Samim',
    'Tel: 93798289276',
    'Email: samiullahsamim735@gmail.com',
  ];

  // 8行分栏 (行 4-11)
  for (let i = 0; i < 8; i++) {
    // 报价方
    ws.mergeCells(`A${4 + i}:C${4 + i}`);
    const supCell = ws.getCell(`A${4 + i}`);
    supCell.value = supplierInfo[i] || '';
    supCell.font = { name: '宋体', size: 10 };
    supCell.alignment = leftMid;
    supCell.border = allBorders;

    // 询价方
    ws.mergeCells(`D${4 + i}:F${4 + i}`);
    const cusCell = ws.getCell(`D${4 + i}`);
    cusCell.value = customerInfo[i] || '';
    cusCell.font = { name: '宋体', size: 10 };
    cusCell.alignment = leftMid;
    cusCell.border = allBorders;
    ws.getRow(4 + i).height = 20;
  }

  // ============ 产品明细表头 (行 12) ============
  const tableHeaders = ['序号', '我司规格型号', '产品名称 / Description', '数量', '含税单价 (¥)', '备注'];
  tableHeaders.forEach((h, i) => {
    const col = String.fromCharCode(65 + i);
    const cell = ws.getCell(`${col}12`);
    cell.value = h;
    cell.font = { name: '宋体', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };
    cell.alignment = centerMid;
    cell.border = allBorders;
  });
  ws.getRow(12).height = 24;

  // ============ 产品明细 ============
  // 价格：未税 RMB × 1.13 = 含税
  const products = [
    {
      no: 1,
      model: 'GDL70-24Z/9.0',
      desc: '9kW Air-Cooled ATC Spindle Motor 风冷自动换刀主轴 (Chinese Bearings 国产轴承, ISO30, 4 Bearings, 18000rpm)',
      qty: 1,
      unit: 14690,  // 13000 × 1.13
      remark: '未税¥13,000 + 税13% = ¥14,690\nUSD: $2,192.54 @ 6.7',
    },
    {
      no: 2,
      model: 'GDL70-24Z/9.0',
      desc: '9kW Air-Cooled ATC Spindle Motor 风冷自动换刀主轴 (NSK Imported Bearings 进口NSK轴承, ISO30, 4 Bearings, 18000rpm)',
      qty: 1,
      unit: 16894,  // 14950 × 1.13
      remark: '未税¥14,950 + 税13% = ¥16,894\nUSD: $2,521.42 @ 6.7',
    },
    {
      no: 3,
      model: 'TBD / 待定',
      desc: '12kW Air-Cooled ATC Spindle Motor 风冷自动换刀主轴 (ISO30, 4 Bearings)',
      qty: 1,
      unit: null,
      remark: '翰祺暂无12kW风冷ATC库存\nSpecial Order: 30-day lead time\nPrice on Request - 待工厂确认',
    },
  ];

  products.forEach((p, i) => {
    const r = 13 + i;
    ws.getCell(`A${r}`).value = p.no;
    ws.getCell(`B${r}`).value = p.model;
    ws.getCell(`C${r}`).value = p.desc;
    ws.getCell(`D${r}`).value = p.qty;

    if (p.unit !== null) {
      ws.getCell(`E${r}`).value = p.unit;
      ws.getCell(`E${r}`).numFmt = '#,##0';
    } else {
      ws.getCell(`E${r}`).value = 'TBD';
    }
    ws.getCell(`F${r}`).value = p.remark;

    ['A', 'B', 'C', 'D', 'E', 'F'].forEach((col) => {
      const cell = ws.getCell(`${col}${r}`);
      cell.font = { name: '宋体', size: 9 };
      cell.border = allBorders;
      if (col === 'A' || col === 'D') {
        cell.alignment = centerMid;
      } else if (col === 'E') {
        cell.alignment = rightMid;
      } else {
        cell.alignment = leftMid;
      }
    });
    ws.getRow(r).height = 56;
  });

  // ============ 备注条款 (行 16 起的4条) ============
  const notesStartRow = 13 + products.length + 1;  // 17
  ws.mergeCells(`A${notesStartRow}:F${notesStartRow}`);
  ws.getCell(`A${notesStartRow}`).value = '备注条款 / Terms & Conditions';
  ws.getCell(`A${notesStartRow}`).font = { name: '宋体', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell(`A${notesStartRow}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell(`A${notesStartRow}`).alignment = leftMid;
  ws.getRow(notesStartRow).height = 22;

  const notes = [
    '1. 报价20天内有效 / Quotation valid for 20 days',
    '2. 含税13%，预付30%，尾款70%款到发货 / 13% tax included, 30% T/T deposit, 70% balance before shipment',
    '3. 质保1年，7天包换 / 1-year warranty, 7-day replacement',
    '4. 有库存5天发货，无库存15-20个工作日 / In stock: 5 days; Out of stock: 15-20 working days',
  ];
  notes.forEach((n, i) => {
    ws.mergeCells(`A${notesStartRow + 1 + i}:F${notesStartRow + 1 + i}`);
    const cell = ws.getCell(`A${notesStartRow + 1 + i}`);
    cell.value = n;
    cell.font = { name: '宋体', size: 9 };
    cell.alignment = leftMid;
    ws.getRow(notesStartRow + 1 + i).height = 18;
  });

  // ============ 转速-转矩数据表 (左侧A:B) ============
  // 9kW高速主轴，18000rpm额定，24000rpm最高
  const curveStartRow = notesStartRow + 1 + notes.length + 2;  // 24
  ws.mergeCells(`A${curveStartRow}:B${curveStartRow}`);
  ws.getCell(`A${curveStartRow}`).value = '转速-转矩 (9kW)';
  ws.getCell(`A${curveStartRow}`).font = { name: '宋体', size: 10, bold: true };
  ws.getCell(`A${curveStartRow}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E1F2' } };
  ws.getCell(`A${curveStartRow}`).alignment = centerMid;
  ws.getCell(`A${curveStartRow}`).border = allBorders;

  // 表头
  ws.getCell(`A${curveStartRow + 1}`).value = '转速 (rpm)';
  ws.getCell(`B${curveStartRow + 1}`).value = '转矩 (N.m)';
  [ws.getCell(`A${curveStartRow + 1}`), ws.getCell(`B${curveStartRow + 1}`)].forEach(c => {
    c.font = { name: '宋体', size: 9, bold: true };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E1F2' } };
    c.alignment = centerMid;
    c.border = allBorders;
  });

  // 9kW主轴典型曲线：恒转矩区到18000rpm（4.77Nm），恒功率区到24000rpm
  const curveData = [
    [0, 4.77],
    [3000, 4.77],
    [6000, 4.77],
    [9000, 4.77],
    [12000, 4.77],
    [15000, 4.77],
    [18000, 4.77],
    [21000, 4.09],
    [24000, 3.58],
  ];

  curveData.forEach((d, i) => {
    const r = curveStartRow + 2 + i;
    ws.getCell(`A${r}`).value = d[0];
    ws.getCell(`B${r}`).value = d[1];
    ws.getCell(`A${r}`).numFmt = '#,##0';
    ws.getCell(`B${r}`).numFmt = '0.00';
    [ws.getCell(`A${r}`), ws.getCell(`B${r}`)].forEach(c => {
      c.font = { name: '宋体', size: 9 };
      c.alignment = centerMid;
      c.border = allBorders;
    });
  });

  // ============ 转速-转矩曲线图 (右侧 C:F) ============
  // 用SVG生成曲线图，转成PNG插入
  const sharp = require('sharp');
  const width = 480, height = 320;
  const margin = { top: 30, right: 20, bottom: 40, left: 50 };
  const plotW = width - margin.left - margin.right;
  const plotH = height - margin.top - margin.bottom;
  const xMin = 0, xMax = 24000;
  const yMin = 0, yMax = 5.5;

  const toX = (v) => margin.left + ((v - xMin) / (xMax - xMin)) * plotW;
  const toY = (v) => margin.top + plotH - ((v - yMin) / (yMax - yMin)) * plotH;

  // 网格
  const xTicks = [0, 6000, 12000, 18000, 24000];
  const yTicks = [0, 1, 2, 3, 4, 5];

  let gridLines = '';
  xTicks.forEach(t => {
    gridLines += `<line x1="${toX(t)}" y1="${margin.top}" x2="${toX(t)}" y2="${margin.top + plotH}" stroke="#E0E0E0" stroke-width="1"/>`;
  });
  yTicks.forEach(t => {
    gridLines += `<line x1="${margin.left}" y1="${toY(t)}" x2="${margin.left + plotW}" y2="${toY(t)}" stroke="#E0E0E0" stroke-width="1"/>`;
  });

  // 坐标轴
  let axes = `
    <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotH}" stroke="#333" stroke-width="1.5"/>
    <line x1="${margin.left}" y1="${margin.top + plotH}" x2="${margin.left + plotW}" y2="${margin.top + plotH}" stroke="#333" stroke-width="1.5"/>
  `;

  // 刻度标签
  let tickLabels = '';
  xTicks.forEach(t => {
    tickLabels += `<text x="${toX(t)}" y="${margin.top + plotH + 15}" text-anchor="middle" font-family="Arial" font-size="10" fill="#333">${t}</text>`;
  });
  yTicks.forEach(t => {
    tickLabels += `<text x="${margin.left - 8}" y="${toY(t) + 3}" text-anchor="end" font-family="Arial" font-size="10" fill="#333">${t}</text>`;
  });

  // 轴标题
  let axisTitles = `
    <text x="${margin.left + plotW / 2}" y="${height - 8}" text-anchor="middle" font-family="Arial" font-size="11" font-weight="bold" fill="#333">Speed (rpm)</text>
    <text x="15" y="${margin.top + plotH / 2}" text-anchor="middle" font-family="Arial" font-size="11" font-weight="bold" fill="#333" transform="rotate(-90 15 ${margin.top + plotH / 2})">Torque (N.m)</text>
  `;

  // 曲线
  const pathD = curveData.map((d, i) => `${i === 0 ? 'M' : 'L'} ${toX(d[0])} ${toY(d[1])}`).join(' ');
  const curve = `<path d="${pathD}" stroke="#1F4E79" stroke-width="2.5" fill="none"/>`;

  // 数据点
  let dataPoints = '';
  curveData.forEach(d => {
    dataPoints += `<circle cx="${toX(d[0])}" cy="${toY(d[1])}" r="3" fill="#1F4E79"/>`;
  });

  // 标题
  const title = `<text x="${width / 2}" y="20" text-anchor="middle" font-family="Arial" font-size="13" font-weight="bold" fill="#1F4E79">9kW ATC Spindle: Speed-Torque Curve</text>`;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
    <rect width="${width}" height="${height}" fill="white"/>
    ${title}
    ${gridLines}
    ${axes}
    ${tickLabels}
    ${axisTitles}
    ${curve}
    ${dataPoints}
  </svg>`;

  const pngPath = 'C:/Users/Administrator/Coze/Drive/扣子/atc_curve_9kw.png';
  await sharp(Buffer.from(svg)).png().toFile(pngPath);

  const imageId = wb.addImage({ filename: pngPath, extension: 'png' });
  // 曲线图放在 C22:F33 大约
  ws.addImage(imageId, {
    tl: { col: 2.2, row: curveStartRow - 0.5 },
    ext: { width: 380, height: 260 }
  });

  // ============ Footer ============
  const footerRow = curveStartRow + 2 + curveData.length + 2;
  ws.mergeCells(`A${footerRow}:F${footerRow}`);
  ws.getCell(`A${footerRow}`).value = '期待您的回复 / Looking forward to your reply.  |  Changzhou JSS Motor Co., Ltd.';
  ws.getCell(`A${footerRow}`).font = { name: '宋体', size: 9, italic: true, color: { argb: 'FF888888' } };
  ws.getCell(`A${footerRow}`).alignment = centerMid;
  ws.getRow(footerRow).height = 22;

  // 保存
  const outPath = 'C:/Users/Administrator/Coze/Drive/扣子/Saeed_Bright_ATC_Quotation_20261013.xlsx';
  await wb.xlsx.writeFile(outPath);
  console.log('Saved:', outPath);
}

main().catch(console.error);
