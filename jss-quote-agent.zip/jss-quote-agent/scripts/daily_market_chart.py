#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""每日市场行情图表 CodeAct 脚本。

每天早上 9:00 定时运行，自动抓取最新市场数据并生成行情图表。

数据来源：
- A股指数（上证指数、沪深300）：新浪财经实时行情 + K线历史 API
- 美股指数（道琼斯、纳斯达克、标普500）：新浪财经实时行情
- 大宗商品（黄金、原油、铜）：新浪财经实时行情
- USD/CNY 汇率：ExchangeRate-API + 新浪财经 + 搜索兜底

图表：6 面板 PNG，A 股带 30 日趋势线，其余指标柱状图展示涨跌幅。
美股/商品历史趋势通过 codeact_fetch_web 抓取 investing.com 获取。

参数（sys.argv）：
- argv[1]: result_mode (display_only / notify / no_reply / auto)
- argv[2]: output_dir (默认 ./codeact/output)
"""

import asyncio
import json
import math
import os
import re
import sys
import traceback
from datetime import datetime, timedelta, timezone

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

import requests
from codeact_sdk import CodeActSDK
from pydantic import BaseModel, Field
from typing import Optional

# ===== SDK 工具版本（get_codeact_tool_schemas 获取后替换占位值） =====
TOOL_SCHEMA_VERSIONS = {
    "codeact_fetch_web": "v1_2c8d0580b3f93a58",
    "codeact_search_web": "v1_5ac1b0eba8c26f2a",
    "file_to_url": "v1_fe3416acf3d7b53b",
}

# ===== 常量 =====
TZ = timezone(timedelta(hours=8))
REQUEST_TIMEOUT = 12

# ---------- 新浪财经 API ----------
SINA_QUOTES_URL = "https://hq.sinajs.cn/list={codes}"
SINA_KLINE_URL = "https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData"
SINA_HEADERS = {"User-Agent": "Mozilla/5.0", "Referer": "https://finance.sina.com.cn"}

# A 股指数代码（新浪格式）
A_SHARE_CODES = {"sh000001": "上证指数", "sh000300": "沪深300"}

# 美股指数代码（新浪格式）—— 使用 gb_ 前缀（30+ 字段，含时间戳和昨收）
# 注意：int_* 前缀只返回 4 个字段且数据严重滞后/冻结，已弃用
US_INDEX_CODES = {"gb_dji": "道琼斯", "gb_ixic": "纳斯达克", "gb_inx": "标普500"}

# 大宗商品代码（新浪格式）
COMMODITY_CODES = {"hf_GC": "黄金(美元/盎司)", "hf_CL": "WTI原油(美元/桶)", "hf_HG": "COMEX铜(美分/磅)"}

# 汇率 API（免费、无需 key）
ER_API_URL = "https://open.er-api.com/v6/latest/USD"

# investing.com 路径（codeact_fetch_web 抓取历史数据用）
INVESTING_PATHS = {
    "黄金": "/commodities/gold",
    "WTI原油(美元/桶)": "/commodities/crude-oil",
    "COMEX铜(美分/磅)": "/commodities/copper",
    "道琼斯": "/indices/us-30",
    "纳斯达克": "/indices/nasdaq-composite",
    "标普500": "/indices/us-spx-500",
}

INVESTING_BASE = "https://www.investing.com"


# ===== Pydantic 结构化模型 =====

class InvestingTableRow(BaseModel):
    """investing.com 历史数据行抽取"""
    date: str = Field(default="", description="日期,如 Oct 22, 2026")
    close: Optional[float] = Field(default=None, description="收盘价/结算价")
    open: Optional[float] = Field(default=None, description="开盘价")
    high: Optional[float] = Field(default=None, description="最高价")
    low: Optional[float] = Field(default=None, description="最低价")
    change_pct: Optional[float] = Field(default=None, description="涨跌幅百分比,如 -1.25")


class InvestingDataExtract(BaseModel):
    """从 investing.com 页面抽取的结构化数据"""
    ok: bool = False
    item_name: str = ""
    current_price: Optional[float] = None
    history: list[InvestingTableRow] = Field(default_factory=list)
    evidence: str = ""


class SearchTrendExtract(BaseModel):
    """从搜索结果摘要中抽取的趋势数据"""
    ok: bool = False
    item_name: str = ""
    current_value: Optional[float] = None
    change_pct: Optional[float] = None
    trend_7d: Optional[str] = Field(default=None, description="近7日走势描述")
    evidence: str = ""


# ===== 工具函数 =====

def _now():
    return datetime.now(TZ)


def _parse_date(s: str) -> Optional[datetime]:
    raw = (s or "").strip()
    if not raw:
        return None
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        pass
    normalized = re.sub(r"([+-]\d{2}:?\d{2})$", "", raw.replace("T", " ")).strip()
    for fmt in ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y年%m月%d日", "%Y/%m/%d", "%Y.%m.%d"]:
        try:
            return datetime.strptime(normalized, fmt)
        except Exception:
            continue
    return None


def _build_publish_time_window(lookback_days: int = 3) -> dict:
    end = _now()
    start = end - timedelta(days=lookback_days)
    return {"start": start.isoformat(timespec="seconds"), "end": end.isoformat(timespec="seconds")}


def _coerce_model(v, model_cls):
    if isinstance(v, model_cls):
        return v
    if isinstance(v, str):
        return model_cls(**json.loads(v))
    if isinstance(v, dict):
        return model_cls(**v)
    raise ValueError(f"LLM 返回格式不可用: {type(v)}")


# ===== Phase 1: 实时行情获取（直接 HTTP API）=====

async def fetch_sina_quotes(codes: dict[str, str], sem: asyncio.Semaphore) -> dict[str, dict]:
    """新浪财经实时行情。codes: {新浪代码: 中文名}"""
    async with sem:
        code_str = ",".join(codes.keys())

        def _fetch():
            r = requests.get(
                SINA_QUOTES_URL.format(codes=code_str),
                headers=SINA_HEADERS, timeout=REQUEST_TIMEOUT,
            )
            r.encoding = "gbk"
            return r.text

        text = await asyncio.to_thread(_fetch)

        results = {}
        for line in text.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            m = re.match(r'var hq_str_(\w+)="(.+)"', line)
            if not m:
                continue
            code = m.group(1)
            fields = m.group(2).split(",")
            name = codes[code]

            if code.startswith("gb_"):
                # 美股指数 (gb_ 前缀): 30+ 字段
                # [0]=名称 [1]=最新价 [2]=涨跌幅% [3]=北京时间 [4]=涨跌额
                # [5]=开盘 [6]=最高 [7]=最低 [25]=美东时间 [26]=昨收
                if len(fields) >= 27:
                    try:
                        value = float(fields[1])
                        prev_close = float(fields[26]) if fields[26] else None
                        change_pct_api = float(fields[2]) if fields[2] else None
                        dt_str = fields[3]  # 北京时间, 如 2026-10-28 04:48:44

                        # 时效性校验：解析数据时间，确认在 72 小时内
                        data_dt = _parse_date(dt_str)
                        is_fresh = True
                        if data_dt:
                            # data_dt 是 naive datetime，与 _now() 比较需统一
                            now_naive = _now().replace(tzinfo=None)
                            age_hours = (now_naive - data_dt).total_seconds() / 3600
                            if age_hours > 72:
                                is_fresh = False
                                print(f"  [警告] {name} 数据已过时: {dt_str} (距今 {age_hours:.1f}h)")

                        # 用 prev_close 计算涨跌幅（优先于接口自带的 change_pct）
                        if prev_close and prev_close > 0:
                            change = value - prev_close
                            change_pct = (change / prev_close * 100)
                        elif change_pct_api is not None:
                            change = value * change_pct_api / 100 if change_pct_api else 0
                            change_pct = change_pct_api
                        else:
                            change = 0
                            change_pct = 0

                        if is_fresh and value > 0:
                            results[code] = {
                                "name": name,
                                "value": value,
                                "prev_close": prev_close,
                                "change": change,
                                "change_pct": change_pct,
                                "date": dt_str,
                                "source": "新浪财经(gb_)",
                            }
                        elif not is_fresh:
                            print(f"  [跳过] {name} 数据过时，不采用")
                    except (ValueError, IndexError) as e:
                        print(f"  [解析失败] {name}: {e}")

            elif code.startswith("int_"):
                # int_* 前缀已弃用（数据冻结），跳过
                pass

            elif code.startswith("hf_"):
                # 大宗商品: price, , bid, ask, high, low, time, prev_close, ...
                if len(fields) >= 8:
                    try:
                        value = float(fields[0])
                        prev_close = float(fields[7]) if fields[7] else None
                        change = value - prev_close if prev_close else 0
                        change_pct = (change / prev_close * 100) if prev_close else 0
                        results[code] = {
                            "name": name,
                            "value": value,
                            "prev_close": prev_close,
                            "change": change,
                            "change_pct": change_pct,
                            "date": fields[9] if len(fields) > 9 else "",
                            "source": "新浪财经",
                        }
                    except (ValueError, IndexError):
                        pass

            elif code.startswith("fx_"):
                # 外汇: time, bid, ask, mid, ...
                if len(fields) >= 4:
                    try:
                        results[code] = {
                            "name": name,
                            "value": float(fields[3]),  # mid price
                            "bid": float(fields[1]),
                            "ask": float(fields[2]),
                            "source": "新浪财经",
                        }
                    except (ValueError, IndexError):
                        pass

            else:
                # A 股指数: name, open, prev_close, current, high, low, ...
                if len(fields) >= 6:
                    try:
                        current = float(fields[3])
                        prev_close = float(fields[2])
                        change = current - prev_close
                        change_pct = (change / prev_close * 100) if prev_close else 0
                        results[code] = {
                            "name": name,
                            "value": current,
                            "prev_close": prev_close,
                            "change": change,
                            "change_pct": change_pct,
                            "date": fields[30] if len(fields) > 30 else "",
                            "source": "新浪财经",
                        }
                    except (ValueError, IndexError):
                        pass

        return results


async def fetch_sina_kline(symbol: str, datalen: int = 30, sem: asyncio.Semaphore = None) -> list[dict]:
    """新浪 K 线 API 获取 A 股日线历史数据"""
    if sem:
        async with sem:
            return await _do_sina_kline(symbol, datalen)
    return await _do_sina_kline(symbol, datalen)


async def _do_sina_kline(symbol: str, datalen: int) -> list[dict]:
    params = {"symbol": symbol, "scale": "240", "ma": "no", "datalen": str(datalen)}

    def _fetch():
        r = requests.get(SINA_KLINE_URL, params=params, headers=SINA_HEADERS, timeout=REQUEST_TIMEOUT)
        r.encoding = "gbk"
        return r.text.strip()

    text = await asyncio.to_thread(_fetch)
    if not text or text == "null":
        return []

    try:
        data = json.loads(text)
        if not isinstance(data, list) or len(data) < 3:
            return []
        return [
            {
                "date": d.get("day", ""),
                "open": float(d.get("open", 0)),
                "high": float(d.get("high", 0)),
                "low": float(d.get("low", 0)),
                "close": float(d.get("close", 0)),
                "volume": float(d.get("volume", 0)),
            }
            for d in data
        ]
    except Exception as e:
        print(f"  [K线] {symbol} 解析失败: {e}")
        return []


async def fetch_exchange_rate(sem: asyncio.Semaphore) -> dict:
    """获取 USD/CNY 汇率：open.er-api.com 主源 → 新浪 fx_susdcny 兜底"""
    # 主源: open.er-api.com
    async with sem:
        def _fetch_er():
            r = requests.get(ER_API_URL, timeout=REQUEST_TIMEOUT)
            return r.json()

        try:
            data = await asyncio.to_thread(_fetch_er)
            rate = float(data["rates"]["CNY"])
            if rate > 0:
                return {
                    "rate": rate,
                    "source": "ExchangeRate-API",
                    "date": data.get("time_last_update_utc", ""),
                }
        except Exception as e:
            print(f"[汇率] ER-API 失败: {e}")

    # 兜底: 新浪外汇
    async with sem:
        def _fetch_sina_fx():
            r = requests.get(
                "https://hq.sinajs.cn/list=fx_susdcny",
                headers=SINA_HEADERS, timeout=REQUEST_TIMEOUT,
            )
            r.encoding = "gbk"
            return r.text

        try:
            text = await asyncio.to_thread(_fetch_sina_fx)
            m = re.search(r'hq_str_fx_susdcny="([^"]+)"', text)
            if m:
                fields = m.group(1).split(",")
                rate = float(fields[3])
                if 3 < rate < 15:
                    return {"rate": rate, "source": "新浪财经外汇", "date": fields[-1] if len(fields) > 30 else ""}
        except Exception as e:
            print(f"[汇率] 新浪外汇兜底失败: {e}")

    raise RuntimeError("所有汇率数据源均失败")


# ===== Phase 2: 历史趋势获取（codeact_fetch_web + LLM 抽取）=====

async def fetch_history_investing(
    sdk: CodeActSDK, item_name: str, sem: asyncio.Semaphore
) -> dict:
    """从 investing.com 获取历史数据（通过 codeact_fetch_web + LLM 结构化抽取）"""
    path = INVESTING_PATHS.get(item_name)
    if not path:
        return {"ok": False, "name": item_name}

    url = f"{INVESTING_BASE}{path}"
    print(f"  [历史] fetching {item_name}: {url}")

    async with sem:
        page = await sdk.call_tool(
            "codeact_fetch_web",
            {"url": url},
            schema_version=TOOL_SCHEMA_VERSIONS["codeact_fetch_web"],
        )

    if not page.get("is_success"):
        print(f"  [历史] {item_name} fetch 失败: {page.get('error', '')}")
        return {"ok": False, "name": item_name}

    content = str(page.get("content") or "")[:12000]
    title = str(page.get("title") or item_name)

    if len(content.strip()) < 100:
        return {"ok": False, "name": item_name}

    try:
        extract = await sdk.call_llm(
            messages=[{
                "role": "user",
                "content": (
                    f"从以下 investing.com 页面提取 {item_name} 的历史行情数据。\n\n"
                    f"页面标题：{title}\n\n"
                    f"页面正文（截取前 12000 字符）：\n{content}\n\n"
                    f"提取要求：\n"
                    f"1. current_price: 当前价格\n"
                    f"2. history: 历史数据表格行（最近 5-20 条），每条包含 date, close, open, high, low, change_pct\n"
                    f"3. 只提取页面中实际出现的数值，不要编造\n"
                    f"4. 设 ok=true 当且仅当提取到了有效数据"
                ),
            }],
            response_format=InvestingDataExtract,
        )
        result = _coerce_model(extract, InvestingDataExtract)
        if result.ok and result.history:
            history = [
                {"date": h.date, "close": h.close, "change_pct": h.change_pct}
                for h in result.history
                if h.close is not None
            ]
            print(f"  [历史] {item_name}: 提取到 {len(history)} 条历史数据, 当前价={result.current_price}")
            return {"ok": True, "name": item_name, "current_price": result.current_price, "history": history, "source": "Investing.com"}
    except Exception as e:
        print(f"  [历史] {item_name} LLM 抽取失败: {e}")

    return {"ok": False, "name": item_name}


async def fetch_trend_via_search(
    sdk: CodeActSDK, item_name: str, search_query: str, sem: asyncio.Semaphore
) -> dict:
    """通过 codeact_search_web 搜索近期行情趋势数据"""
    print(f"  [搜索趋势] {item_name}: {search_query}")
    async with sem:
        search = await sdk.call_tool(
            "codeact_search_web",
            {
                "query": search_query,
                "publish_time": _build_publish_time_window(3),
                "response_length": "medium",
            },
            schema_version=TOOL_SCHEMA_VERSIONS["codeact_search_web"],
        )

    if not search.get("is_success"):
        return {"ok": False, "name": item_name}

    results = search.get("results") or []
    if not results:
        return {"ok": False, "name": item_name}

    # 取前 5 条搜索结果，让 LLM 抽取趋势数据
    snippets = []
    for r in results[:5]:
        snippets.append(
            f"标题: {r.get('title', '')}\n"
            f"摘要: {r.get('snippet', '')}\n"
            f"时间: {r.get('publish_time', '未知')}"
        )

    try:
        extract = await sdk.call_llm(
            messages=[{
                "role": "user",
                "content": (
                    f"从以下搜索结果中提取 {item_name} 的最新行情数据。\n\n"
                    + "\n---\n".join(snippets)
                    + "\n\n提取要求：\n"
                    "1. current_value: 最新价格/点位\n"
                    "2. change_pct: 涨跌幅百分比\n"
                    "3. trend_7d: 近 7 日走势简述（如'震荡上涨'、'连续下跌'等）\n"
                    "4. 只基于搜索结果中明确出现的数据，不要编造"
                ),
            }],
            response_format=SearchTrendExtract,
        )
        result = _coerce_model(extract, SearchTrendExtract)
        if result.ok and result.current_value is not None:
            print(f"  [搜索趋势] {item_name}: 值={result.current_value}, 涨跌={result.change_pct}%")
            return {
                "ok": True, "name": item_name,
                "current_value": result.current_value,
                "change_pct": result.change_pct,
                "trend_7d": result.trend_7d,
                "source": "网络搜索",
            }
    except Exception as e:
        print(f"  [搜索趋势] {item_name} LLM 抽取失败: {e}")

    return {"ok": False, "name": item_name}


# ===== Phase 3: 图表生成 =====

def setup_chinese_font():
    """配置中文字体"""
    font_candidates = ["Noto Sans CJK SC", "Noto Sans CJK", "WenQuanYi Micro Hei", "SimHei", "Heiti SC"]
    available = {f.name for f in fm.fontManager.ttflist}
    for font_name in font_candidates:
        if font_name in available:
            plt.rcParams["font.sans-serif"] = [font_name, "DejaVu Sans"]
            break
    else:
        plt.rcParams["font.sans-serif"] = ["DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False


def generate_chart(
    a_share_data: dict,
    us_index_data: dict,
    commodity_data: dict,
    exchange_rate: dict,
    a_share_history: dict,
    investing_history: dict,
    date_str: str,
    output_dir: str,
) -> Optional[str]:
    """生成 3×2 行情面板图表"""
    setup_chinese_font()

    fig, axes = plt.subplots(3, 2, figsize=(16, 18))
    fig.suptitle(f"📊 每日市场行情总览  {date_str}", fontsize=17, fontweight="bold", y=0.97)

    # 面板数据
    panels = []

    # 1. 上证指数（30 日趋势线）
    sh_hist = a_share_history.get("sh000001", [])
    panels.append(("sh000001", a_share_data.get("sh000001"), sh_hist, "#C62828"))

    # 2. USD/CNY 汇率
    panels.append(("fx_usdcny", exchange_rate, None, "#1565C0"))

    # 3. 黄金
    panels.append(("hf_GC", commodity_data.get("hf_GC"), investing_history.get("黄金"), "#E65100"))

    # 4. WTI 原油
    panels.append(("hf_CL", commodity_data.get("hf_CL"), investing_history.get("WTI原油(美元/桶)"), "#2E7D32"))

    # 5. 美股三大指数（柱状图）
    panels.append(("us_indices", us_index_data, investing_history.get("_us_indices"), "#6A1B9A"))

    # 6. COMEX 铜
    panels.append(("hf_HG", commodity_data.get("hf_HG"), investing_history.get("COMEX铜(美分/磅)"), "#00838F"))

    for idx, (key, data, history, color) in enumerate(panels):
        row, col = divmod(idx, 2)
        ax = axes[row][col]
        _render_panel(ax, key, data, history, color)

    # 底部注释
    sources = set()
    for d in [a_share_data, us_index_data, commodity_data]:
        for v in d.values():
            if isinstance(v, dict) and v.get("source"):
                sources.add(v["source"])
    if exchange_rate and exchange_rate.get("source"):
        sources.add(exchange_rate["source"])
    sources_str = "、".join(sorted(sources)) if sources else "公开数据源"
    fig.text(
        0.5, 0.01,
        f"数据来源：{sources_str} | 生成时间：{_now().strftime('%Y-%m-%d %H:%M:%S')} (UTC+8)",
        ha="center", fontsize=9, color="gray", style="italic",
    )

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    chart_path = os.path.join(output_dir, f"market_{_now().strftime('%Y%m%d')}.png")
    fig.savefig(chart_path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return chart_path


def _render_panel(ax, key, data, history, color):
    """渲染单个面板"""
    if key.startswith("sh") and data and history:
        _render_a_share_trend(ax, data, history, color)
    elif key == "fx_usdcny" and data:
        _render_exchange_rate_panel(ax, data, color)
    elif key.startswith("hf_") and data:
        _render_commodity_panel(ax, data, history, color)
    elif key == "us_indices" and data:
        _render_us_indices_panel(ax, data, color)
    else:
        ax.text(0.5, 0.5, "暂无数据", ha="center", va="center", transform=ax.transAxes, fontsize=14, color="gray")
        ax.set_title(key)
    ax.grid(True, alpha=0.3, linestyle="--")


def _render_a_share_trend(ax, data, history, color):
    """A 股指数 30 日趋势线"""
    closes = [d["close"] for d in history if d.get("close")]
    dates = [d["date"] for d in history if d.get("close")]
    if len(closes) < 3:
        ax.text(0.5, 0.5, "历史数据不足", ha="center", va="center", transform=ax.transAxes)
        return

    x = range(len(closes))
    ax.fill_between(x, closes, alpha=0.25, color=color)
    ax.plot(list(x), closes, color=color, linewidth=2.2, marker="o", markersize=2.5, zorder=3)

    value = data["value"]
    pct = data["change_pct"]
    sign = "+" if pct >= 0 else ""
    ax.set_title(f"{data['name']}  {value:,.2f}  ({sign}{pct:.2f}%)", fontsize=12, fontweight="bold", color=color)

    step = max(1, len(dates) // 6)
    ax.set_xticks(list(x)[::step])
    ax.set_xticklabels([d[5:].replace("-", "/") for d in dates[::step]], rotation=30, fontsize=8)
    ax.set_ylabel("点")
    _add_trend_annotation(ax, closes, pct, color)


def _render_exchange_rate_panel(ax, rate_data, color):
    """汇率面板"""
    rate = rate_data["rate"]
    source = rate_data.get("source", "")

    ax.bar(["USD/CNY"], [rate], color=color, alpha=0.75, width=0.5)
    ax.set_title(f"美元兑人民币  {rate:.4f}", fontsize=12, fontweight="bold", color=color)
    ax.set_ylabel("汇率")
    ax.set_ylim(max(6.0, rate - 0.15), min(8.0, rate + 0.15))

    for i, v in enumerate([rate]):
        ax.text(i, v + 0.008, f"{v:.4f}", ha="center", fontsize=12, fontweight="bold")

    # 参考线：6.7（用户常用出口报价汇率）
    ax.axhline(y=6.7, color="gray", linestyle=":", alpha=0.5, linewidth=1)
    ax.text(len(["USD/CNY"]) - 0.6, 6.7 + 0.01, "参考线 6.7", fontsize=8, color="gray", ha="center")
    ax.text(0.5, 0.02, f"来源: {source}", transform=ax.transAxes, fontsize=8, color="gray", ha="center")


def _render_commodity_panel(ax, data, history, color):
    """大宗商品面板"""
    if history and len(history) >= 3:
        closes = [h["close"] for h in history if h.get("close") is not None]
        if len(closes) >= 3:
            x = range(len(closes))
            ax.fill_between(x, closes, alpha=0.25, color=color)
            ax.plot(list(x), closes, color=color, linewidth=2, marker="o", markersize=2.5, zorder=3)
            pct = data.get("change_pct", 0)
            _add_trend_annotation(ax, closes, pct, color)
            ax.set_title(f"{data['name']}  {data['value']:,.2f}  ({pct:+.2f}%)", fontsize=11, fontweight="bold", color=color)
            return

    # 回退：单值柱状图
    ax.bar([data["name"]], [data["value"]], color=color, alpha=0.75, width=0.5)
    ax.text(0, data["value"] * 1.01, f"{data['value']:,.2f}", ha="center", fontsize=11, fontweight="bold")
    pct = data.get("change_pct", 0)
    sign = "+" if pct >= 0 else ""
    ax.set_title(f"{data['name']}  {data['value']:,.2f}  ({sign}{pct:.2f}%)", fontsize=11, fontweight="bold", color=color)


def _render_us_indices_panel(ax, us_data, color):
    """美股三大指数柱状图"""
    names = []
    pcts = []
    colors = []
    for code, info in us_data.items():
        if not isinstance(info, dict):
            continue
        short = info.get("name", code)
        names.append(short)
        pct = info.get("change_pct", 0)
        pcts.append(pct)
        colors.append("#4CAF50" if pct >= 0 else "#F44336")

    if not names:
        ax.text(0.5, 0.5, "暂无数据", ha="center", va="center", transform=ax.transAxes)
        return

    bars = ax.bar(names, pcts, color=colors, alpha=0.8, width=0.5)
    ax.set_title("美股三大指数  涨跌幅(%)", fontsize=12, fontweight="bold", color=color)
    ax.set_ylabel("涨跌幅 (%)")
    ax.axhline(y=0, color="gray", linestyle="-", linewidth=0.8)

    for bar, pct, info in zip(bars, pcts, us_data.values()):
        if not isinstance(info, dict):
            continue
        y_pos = bar.get_height()
        va = "bottom" if y_pos >= 0 else "top"
        ax.text(
            bar.get_x() + bar.get_width() / 2, y_pos,
            f"{info['value']:,.0f}\n{pct:+.2f}%",
            ha="center", va=va, fontsize=9, fontweight="bold",
        )


def _add_trend_annotation(ax, closes, pct, color):
    """在趋势线末端添加涨跌箭头"""
    if not closes:
        return
    arrow = "▲" if pct >= 0 else "▼"
    sign = "+" if pct >= 0 else ""
    ann_color = "#4CAF50" if pct >= 0 else "#F44336"
    ax.annotate(
        f" {arrow} {sign}{pct:.2f}%",
        xy=(len(closes) - 1, closes[-1]),
        fontsize=9, color=ann_color, fontweight="bold",
        xytext=(5, 5), textcoords="offset points",
    )


# ===== Phase 4: 文字摘要 =====

def build_summary(
    a_share_data, us_index_data, commodity_data, exchange_rate,
    investing_history, search_trends, errors,
) -> str:
    lines = [f"📊 每日市场行情  {_now().strftime('%Y-%m-%d')}"]
    lines.append("")

    # A 股
    lines.append("【A股指数】")
    a_sources = set()
    for code, info in a_share_data.items():
        if isinstance(info, dict) and "value" in info:
            sign = "+" if info["change_pct"] >= 0 else ""
            emoji = "📈" if info["change_pct"] >= 0 else "📉"
            lines.append(f"  {emoji} {info['name']}：{info['value']:,.2f} ({sign}{info['change_pct']:.2f}%)")
            if info.get("prev_close"):
                lines.append(f"     基准：前收 {info['prev_close']:,.2f}")
            src = info.get("source", "新浪财经")
            a_sources.add(src.split("(")[0] if "(" in src else src)
    lines.append(f"  来源：{'、'.join(sorted(a_sources))}")
    lines.append("")

    # USD/CNY
    if exchange_rate and exchange_rate.get("rate"):
        lines.append("【汇率】")
        lines.append(f"  💱 USD/CNY：{exchange_rate['rate']:.4f}")
        lines.append(f"  来源：{exchange_rate.get('source', '未知')}")
        lines.append("")

    # 大宗商品
    lines.append("【大宗商品】")
    for code, info in commodity_data.items():
        if isinstance(info, dict) and "value" in info:
            sign = "+" if info.get("change_pct", 0) >= 0 else ""
            emoji = "📈" if info.get("change_pct", 0) >= 0 else "📉"
            lines.append(f"  {emoji} {info['name']}：{info['value']:,.2f} ({sign}{info.get('change_pct', 0):.2f}%)")

    hist_sources = []
    for name, h in investing_history.items():
        if isinstance(h, dict) and h.get("ok"):
            hist_sources.append(name)
    for name, t in search_trends.items():
        if isinstance(t, dict) and t.get("ok"):
            hist_sources.append(name)
    if hist_sources:
        lines.append(f"  趋势数据来源：{', '.join(hist_sources)}")
    else:
        lines.append(f"  来源：新浪财经")
    lines.append("")

    # 美股
    lines.append("【美股指数】")
    us_sources = set()
    for code, info in us_index_data.items():
        if isinstance(info, dict) and "value" in info:
            sign = "+" if info["change_pct"] >= 0 else ""
            emoji = "📈" if info["change_pct"] >= 0 else "📉"
            lines.append(f"  {emoji} {info['name']}：{info['value']:,.2f} ({sign}{info['change_pct']:.2f}%)")
            if info.get("prev_close"):
                lines.append(f"     基准：前收 {info['prev_close']:,.2f}  数据时间：{info.get('date', '')}")
            us_sources.add(info.get("source", "新浪财经"))
    lines.append(f"  来源：{'、'.join(sorted(us_sources)) if us_sources else '新浪财经'}")
    lines.append("")

    # 失败项
    real_errors = [e for e in errors if e]
    if real_errors:
        lines.append("⚠️ 以下数据获取失败：" + "、".join(real_errors))
        lines.append("")

    lines.append(f"更新时间：{_now().strftime('%H:%M:%S')} (UTC+8)")
    return "\n".join(lines)


# ===== 主流程 =====

async def main():
    result_mode = sys.argv[1] if len(sys.argv) > 1 else "display_only"
    output_dir = sys.argv[2] if len(sys.argv) > 2 else "./codeact/output"

    mode = (result_mode or "display_only").strip().lower()
    if mode not in ("display_only", "notify", "no_reply", "auto"):
        mode = "display_only"

    os.makedirs(output_dir, exist_ok=True)
    now = _now()
    date_str = now.strftime("%Y-%m-%d")

    sdk = CodeActSDK()

    try:
        print(f"[启动] 每日市场行情 | {date_str} | result_mode={mode}")

        sem = asyncio.Semaphore(4)
        errors = []

        # ===== Phase 1: 并行获取实时行情 =====
        print("[Phase 1] 获取实时行情...")

        a_share_task = fetch_sina_quotes(A_SHARE_CODES, sem)
        us_index_task = fetch_sina_quotes(US_INDEX_CODES, sem)
        commodity_task = fetch_sina_quotes(COMMODITY_CODES, sem)
        rate_task = fetch_exchange_rate(sem)

        results = await asyncio.gather(a_share_task, us_index_task, commodity_task, rate_task, return_exceptions=True)

        a_share_data = results[0] if not isinstance(results[0], Exception) else {}
        us_index_data = results[1] if not isinstance(results[1], Exception) else {}
        commodity_data = results[2] if not isinstance(results[2], Exception) else {}
        exchange_rate = results[3] if not isinstance(results[3], Exception) else {}

        if isinstance(results[0], Exception):
            errors.append(f"A股行情: {results[0]}")
            print(f"  [失败] A股: {results[0]}")
        else:
            print(f"  [OK] A股: {len(a_share_data)} 项")

        if isinstance(results[1], Exception):
            errors.append(f"美股行情: {results[1]}")
            print(f"  [失败] 美股: {results[1]}")
        else:
            print(f"  [OK] 美股: {len(us_index_data)} 项")

        if isinstance(results[2], Exception):
            errors.append(f"商品行情: {results[2]}")
            print(f"  [失败] 商品: {results[2]}")
        else:
            print(f"  [OK] 商品: {len(commodity_data)} 项")

        if isinstance(results[3], Exception):
            errors.append(f"汇率: {results[3]}")
            print(f"  [失败] 汇率: {results[3]}")
        else:
            print(f"  [OK] 汇率: {exchange_rate.get('rate', '?')}")

        # 获取 A 股 30 日 K 线历史
        print("[Phase 1b] 获取 A 股 30 日 K 线...")
        a_share_history = {}
        kline_results = await asyncio.gather(
            *(fetch_sina_kline(code, 30, sem) for code in A_SHARE_CODES.keys()),
            return_exceptions=True,
        )
        for code, result in zip(A_SHARE_CODES.keys(), kline_results):
            if isinstance(result, Exception):
                print(f"  [K线失败] {code}: {result}")
            elif result:
                a_share_history[code] = result
                print(f"  [K线OK] {code}: {len(result)} 条")

        # ===== Phase 1c: A 股涨跌幅修正（用 K 线历史获取真实昨收）=====
        print("[Phase 1c] 修正 A 股涨跌幅...")
        for code in A_SHARE_CODES.keys():
            a_data = a_share_data.get(code)
            kline = a_share_history.get(code, [])
            if not a_data or not kline or len(kline) < 2:
                continue

            api_current = a_data.get("value", 0)
            api_prev = a_data.get("prev_close", 0)

            # K 线最后一条 = 最近已完成的交易日
            kline_last = kline[-1]  # 最近完成交易日
            kline_prev = kline[-2]  # 再前一个交易日

            # 判断市场是否已开盘：
            # 若 API 的 current ≈ API 的 prev_close（差值 < 0.01%），说明盘前数据未更新
            market_open = abs(api_current - api_prev) > api_prev * 0.0001 if api_prev > 0 else False

            if market_open:
                # 市场已开盘：用 API 实时价作为 current，K 线最后一条的 close 作为真实昨收
                true_prev = kline_last["close"]
                true_current = api_current
                print(f"  [修正] {code}: 已开盘, 实时价={true_current:.2f}, K线昨收={true_prev:.2f}")
            else:
                # 市场未开盘：K 线最后一条 = 昨收，倒数第二条 = 前日收盘
                true_prev = kline_prev["close"]
                true_current = kline_last["close"]
                print(f"  [修正] {code}: 未开盘, 最新收盘={true_current:.2f}, 前日收盘={true_prev:.2f}")

            # 重新计算涨跌幅
            if true_prev > 0:
                true_change = true_current - true_prev
                true_pct = (true_change / true_prev * 100)
                a_data["value"] = true_current
                a_data["prev_close"] = true_prev
                a_data["change"] = true_change
                a_data["change_pct"] = true_pct
                a_data["source"] = f"新浪财经+K线修正(基准:{kline_prev['date']})"
                print(f"  [结果] {a_data['name']}: {true_current:.2f} ({true_pct:+.2f}%), 基准日={kline_prev['date']}")

        total_data = len(a_share_data) + len(us_index_data) + len(commodity_data) + (1 if exchange_rate else 0)
        if total_data == 0:
            raise RuntimeError("所有实时行情数据获取失败")

        # ===== Phase 2: 美股/商品历史趋势（codeact_fetch_web + LLM 抽取）=====
        print("[Phase 2] 获取美股/商品历史趋势...")
        investing_history = {}
        search_trends = {}

        trend_items = list(COMMODITY_CODES.values()) + list(US_INDEX_CODES.values())
        # 用英文名匹配 investing.com 路径
        name_map = {
            "黄金(美元/盎司)": "黄金",
            "WTI原油(美元/桶)": "WTI原油(美元/桶)",
            "COMEX铜(美分/磅)": "COMEX铜(美分/磅)",
            "道琼斯": "道琼斯",
            "纳斯达克": "纳斯达克",
            "标普500": "标普500",
        }
        search_queries = {
            "黄金(美元/盎司)": f"国际金价 黄金价格 {date_str} 美元/盎司 涨跌",
            "WTI原油(美元/桶)": f"WTI原油价格 {date_str} 美元/桶 涨跌",
            "COMEX铜(美分/磅)": f"COMEX铜价 {date_str} 美分/磅 涨跌",
            "道琼斯": f"道琼斯指数 {date_str} 收盘 涨跌",
            "纳斯达克": f"纳斯达克指数 {date_str} 收盘 涨跌",
            "标普500": f"标普500指数 {date_str} 收盘 涨跌",
        }

        sem2 = asyncio.Semaphore(3)
        for item_name in trend_items:
            inv_name = name_map.get(item_name, item_name)
            # 先尝试 investing.com
            inv_result = await fetch_history_investing(sdk, inv_name, sem2)
            if inv_result.get("ok"):
                investing_history[inv_name] = inv_result
            else:
                # 搜索兜底
                query = search_queries.get(item_name, f"{item_name} 今日 行情 价格 涨跌")
                st = await fetch_trend_via_search(sdk, item_name, query, sem2)
                if st.get("ok"):
                    search_trends[item_name] = st

        print(f"[Phase 2 完成] investing.com: {len(investing_history)} 项, 搜索兜底: {len(search_trends)} 项")

        # ===== Phase 2b: 美股指数兜底（主源失败时用搜索补全）=====
        us_name_to_code = {v: k for k, v in US_INDEX_CODES.items()}
        for us_name, us_code in us_name_to_code.items():
            if us_code in us_index_data:
                continue  # 主源已有数据，跳过
            # 尝试从 search_trends 补全
            st = search_trends.get(us_name)
            if st and st.get("ok") and st.get("current_value"):
                val = st["current_value"]
                pct = st.get("change_pct") or 0
                us_index_data[us_code] = {
                    "name": us_name,
                    "value": val,
                    "change_pct": pct,
                    "change": val * pct / 100 if pct else 0,
                    "prev_close": None,
                    "date": date_str,
                    "source": "网络搜索兜底",
                }
                print(f"  [兜底] {us_name}: {val:.2f} ({pct:+.2f}%) 来源=搜索")
            else:
                # 最后尝试：直接用当天日期搜索
                query = f"{us_name}指数 {date_str} 收盘点位 涨跌幅"
                print(f"  [再兜底] {us_name}: 搜索 {query}")
                st2 = await fetch_trend_via_search(sdk, us_name, query, sem2)
                if st2 and st2.get("ok") and st2.get("current_value"):
                    val = st2["current_value"]
                    pct = st2.get("change_pct") or 0
                    us_index_data[us_code] = {
                        "name": us_name,
                        "value": val,
                        "change_pct": pct,
                        "change": val * pct / 100 if pct else 0,
                        "prev_close": None,
                        "date": date_str,
                        "source": "网络搜索兜底(当日)",
                    }
                    print(f"  [兜底成功] {us_name}: {val:.2f} ({pct:+.2f}%)")
                else:
                    errors.append(f"美股{us_name}: 主源和搜索均失败")
                    print(f"  [失败] {us_name}: 所有数据源均失败")

        # ===== Phase 3: 生成图表 =====
        print("[Phase 3] 生成行情图表...")
        chart_path = None
        try:
            chart_path = generate_chart(
                a_share_data, us_index_data, commodity_data, exchange_rate,
                a_share_history, investing_history, date_str, output_dir,
            )
            print(f"[图表] 已保存: {chart_path}")
        except Exception as e:
            print(f"[图表] 生成失败: {e}，尝试简化...")
            try:
                # 简化图表：跳过历史趋势
                chart_path = generate_chart(
                    a_share_data, us_index_data, commodity_data, exchange_rate,
                    {}, {}, date_str, output_dir,
                )
                print(f"[图表] 简化版已保存: {chart_path}")
            except Exception as e2:
                print(f"[图表] 简化版也失败: {e2}")
                errors.append(f"图表生成: {e2}")

        # ===== Phase 4: 构建摘要 =====
        summary = build_summary(
            a_share_data, us_index_data, commodity_data, exchange_rate,
            investing_history, search_trends, errors,
        )

        # 如果有图表，在摘要中引用
        if chart_path:
            abs_path = os.path.abspath(chart_path)
            summary += f"\n\n📈 [行情图表](computer://{abs_path})"

        # 判断 result_mode
        actual_mode = mode
        if mode == "auto":
            actual_mode = "display_only" if total_data >= 3 else "no_reply"

        print(f"[完成] 数据项={total_data}, chart={'✓' if chart_path else '✗'}, mode={actual_mode}")

        await sdk.submit_result(
            result_mode=actual_mode,
            status="success",
            message=summary,
            data={
                "chart_path": chart_path or "",
                "date": date_str,
                "data_count": total_data,
                "failed_items": [e for e in errors if e],
                "a_share_count": len(a_share_data),
                "us_index_count": len(us_index_data),
                "commodity_count": len(commodity_data),
                "has_exchange_rate": bool(exchange_rate),
            },
        )

    except Exception as e:
        print(f"[致命错误] {e}\n{traceback.format_exc()}")
        await sdk.submit_result(
            result_mode="notify",
            status="error",
            message=f"每日市场行情获取失败：{e}",
            data={"error_type": type(e).__name__},
        )


if __name__ == "__main__":
    asyncio.run(main())
