const ExcelJS = require('exceljs');

(async () => {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('报价单', {
    views: [{ showGridLines: false }]
  });

  // 合并单元格
  const merges = [
    'A1:F1', 'A2:F2',
    'A3:C3', 'D3:F3',
    'A4:C4', 'D4:F4',
    'A5:C5', 'D5:F5',
    'A6:C6', 'D6:F6',
    'A7:C7', 'D7:F7',
    'A8:C8', 'D8:F8',
    'A9:C9', 'D9:F9',
    'A10:F10',
    'A14:F14', 'A15:F15', 'A16:F16', 'A17:F17', 'A18:F18',
    'A20:B20',
  ];
  merges.forEach(range => {
    try { ws.mergeCells(range); } catch(e) {}
  });

  // 标题
  ws.getCell('A1').value = '工业品报价单';
  ws.getCell('A1').font = { name: '宋体', size: 18, bold: true };
  ws.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(1).height = 32;

  // 报单编号
  ws.getCell('A2').value = '报单编号：JSS-20261013-MIA          时间：2026/10/13';
  ws.getCell('A2').alignment = { horizontal: 'left', vertical: 'middle' };
  ws.getCell('A2').font = { name: '宋体', size: 11 };
  ws.getRow(2).height = 22;

  // 报价方/询价方
  const parties = [
    [3, '报价方：常州市金三士机电有限公司', '询价方：Mia'],
    [4, '联系人：销售部', '联系人：Mia'],
    [5, '电  话：+86-519-86922057', '电  话：'],
    [6, '传  真：+86-519-86922057', '传  真：'],
    [7, '手  机：18896754675', '手  机：'],
    [8, 'E-mail：', 'E-mail：'],
    [9, '地址：江苏省常州市', '地址：'],
  ];
  parties.forEach(([row, left, right]) => {
    ws.getCell(`A${row}`).value = left;
    ws.getCell(`D${row}`).value = right;
    ws.getCell(`A${row}`).alignment = { horizontal: 'left', vertical: 'middle' };
    ws.getCell(`D${row}`).alignment = { horizontal: 'left', vertical: 'middle' };
    ws.getCell(`A${row}`).font = { name: '宋体', size: 11 };
    ws.getCell(`D${row}`).font = { name: '宋体', size: 11 };
    ws.getRow(row).height = 22;
  });

  // 边框（左侧9行）
  for (let row = 1; row <= 9; row++) {
    for (let col = 1; col <= 6; col++) {
      ws.getCell(row, col).border = {
        top: { style: 'thin' }, bottom: { style: 'thin' },
        left: { style: 'thin' }, right: { style: 'thin' }
      };
    }
  }

  // 提示语
  ws.getCell('A10').value = '以下为贵司询价产品明细，请详阅；如有疑问，请及时与我司联系，谢谢！';
  ws.getCell('A10').alignment = { horizontal: 'left', vertical: 'middle' };
  ws.getCell('A10').font = { name: '宋体', size: 11 };
  ws.getRow(10).height = 22;

  // 表头
  const headers = ['序号', '产品名称', '我司规格型号', '方案', '单价（元）', '备注'];
  headers.forEach((h, i) => {
    const cell = ws.getCell(11, i + 1);
    cell.value = h;
    cell.font = { name: '宋体', size: 11, bold: true };
    cell.alignment = { horizontal: 'center', vertical: 'middle' };
    cell.border = {
      top: { style: 'thin' }, bottom: { style: 'thin' },
      left: { style: 'thin' }, right: { style: 'thin' }
    };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE7E6E6' } };
  });
  ws.getRow(11).height = 22;

  // 产品明细
  const productRow = [1, '闭环电机+驱动器+屏蔽线套装', '1303P286-7003A', '样品价\n(10套起)', 2250, '闭环电机+3HSS2206+3米屏蔽线\n批量价(1500套): 1960元/套 含税'];
  productRow.forEach((v, i) => {
    const cell = ws.getCell(12, i + 1);
    cell.value = v;
    cell.font = { name: '宋体', size: 11 };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = {
      top: { style: 'thin' }, bottom: { style: 'thin' },
      left: { style: 'thin' }, right: { style: 'thin' }
    };
  });
  ws.getRow(12).height = 40;

  // 备注
  const notes = [
    [14, '备注：'],
    [15, '1. 本报价在20天之内有效，超过20天请重新询价；'],
    [16, '2. 以上报价为含税报价，开13%增值税发票，下单预付30%货款，尾款70%款到发货；'],
    [17, '3. 报价单内产品质保期为1年，7天包换(质量问题包退换、人为损坏由客户承担维修费用），终生维修；'],
    [18, '4. 如有库存，将在五天内发货；如无库存，样品生产周期为15-20个工作日；'],
  ];
  notes.forEach(([row, text]) => {
    ws.getCell(`A${row}`).value = text;
    ws.getCell(`A${row}`).font = { name: '宋体', size: 11 };
    ws.getCell(`A${row}`).alignment = { horizontal: 'left', vertical: 'middle' };
    ws.getRow(row).height = 22;
  });

  // 转速-转矩数据（闭环：开环×1.10）
  ws.getCell('A20').value = '转速(rpm)';
  ws.getCell('B20').value = '转矩(N.m)';
  ws.getCell('A20').font = { name: '宋体', size: 11, bold: true };
  ws.getCell('B20').font = { name: '宋体', size: 11, bold: true };
  ws.getCell('A20').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getCell('B20').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getCell('A20').border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
  ws.getCell('B20').border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };

  // 闭环电机数据：开环基础上 +10%
  const curveData = [
    [0, 55], [50, 54], [100, 52], [150, 48], [200, 44],
    [250, 39], [300, 32], [350, 25], [400, 19], [450, 13], [500, 9]
  ];
  curveData.forEach(([rpm, torque], i) => {
    const row = 21 + i;
    ws.getCell(`A${row}`).value = rpm;
    ws.getCell(`B${row}`).value = torque;
    ws.getCell(`A${row}`).alignment = { horizontal: 'center' };
    ws.getCell(`B${row}`).alignment = { horizontal: 'center' };
    ws.getCell(`A${row}`).border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
    ws.getCell(`B${row}`).border = { top: { style: 'thin' }, bottom: { style: 'thin' }, left: { style: 'thin' }, right: { style: 'thin' } };
  });

  // 曲线图标题
  ws.mergeCells('D13:F13');
  ws.getCell('D13').value = '1303P286闭环电机特性曲线 (220V)';
  ws.getCell('D13').font = { name: '宋体', size: 11, bold: true };
  ws.getCell('D13').alignment = { horizontal: 'center', vertical: 'middle' };

  // 转速-转矩曲线图
  const imageId = wb.addImage({
    filename: 'curve_chart.png',
    extension: 'png',
  });
  ws.addImage(imageId, {
    tl: { col: 3.5, row: 13.5 },
    ext: { width: 350, height: 280 }
  });

  // 边框 - 备注
  for (let row = 14; row <= 18; row++) {
    for (let col = 1; col <= 6; col++) {
      ws.getCell(row, col).border = {
        top: { style: 'thin' }, bottom: { style: 'thin' },
        left: { style: 'thin' }, right: { style: 'thin' }
      };
    }
  }

  // 列宽
  ws.getColumn(1).width = 10;
  ws.getColumn(2).width = 24;
  ws.getColumn(3).width = 18;
  ws.getColumn(4).width = 14;
  ws.getColumn(5).width = 14;
  ws.getColumn(6).width = 38;

  await wb.xlsx.writeFile('JSS-20261013-MIA报价单.xlsx');
  console.log('Generated: JSS-20261013-MIA报价单.xlsx');
})();
