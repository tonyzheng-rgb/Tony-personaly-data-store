const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');

const tmpHtml = path.join(require('os').tmpdir(), 'atc_quote.html');
const outPath = 'C:\\Users\\Administrator\\Coze\\Drive\\扣子\\Saeed_Bright_ATC_Quotation_20261013.pdf';

(async () => {
  try {
    const browser = await puppeteer.launch({
      headless: 'new',
      executablePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    const page = await browser.newPage();
    await page.goto('file:///' + tmpHtml.replace(/\\/g, '/'), { waitUntil: 'networkidle0' });
    await page.pdf({
      path: outPath,
      format: 'A4',
      landscape: true,
      printBackground: true,
      margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' }
    });
    await browser.close();
    if (fs.existsSync(outPath)) {
      console.log('PDF saved:', outPath, fs.statSync(outPath).size, 'bytes');
    } else {
      console.error('PDF NOT created');
    }
  } catch (e) {
    console.error('Error:', e.message);
  }
})();
