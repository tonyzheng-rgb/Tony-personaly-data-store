// 英文报价单生成 - 翰祺9kW/12kW风冷自动换刀主轴
const ExcelJS = require('exceljs');

async function main() {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Quotation');

  // 边距
  ws.pageSetup = { margins: { left: 0.5, right: 0.5, top: 0.5, bottom: 0.5 } };

  // 列宽
  ws.columns = [
    { width: 4 },    // A: 边距
    { width: 6 },    // B: NO
    { width: 50 },   // C: Description
    { width: 18 },   // D: Model
    { width: 8 },    // E: Qty
    { width: 16 },   // F: Unit Price
    { width: 16 },   // G: Total
  ];

  const thin = { style: 'thin', color: { argb: 'FF000000' } };
  const allBorders = { top: thin, left: thin, bottom: thin, right: thin };

  // === Header - 标题栏（深蓝底）===
  ws.mergeCells('B2:G2');
  ws.getCell('B2').value = 'CHANGZHOU JSS MOTOR CO., LTD.';
  ws.getCell('B2').font = { name: 'Arial', size: 18, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('B2').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell('B2').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(2).height = 36;

  ws.mergeCells('B3:G3');
  ws.getCell('B3').value = '常州市金三士机电有限公司   |   www.jss-motor.com   |   info@jss-motor.com';
  ws.getCell('B3').font = { name: 'Arial', size: 9, italic: true, color: { argb: 'FF555555' } };
  ws.getCell('B3').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(3).height = 18;

  // === QUOTATION 大标题 ===
  ws.mergeCells('B5:G5');
  ws.getCell('B5').value = 'QUOTATION';
  ws.getCell('B5').font = { name: 'Arial', size: 22, bold: true, color: { argb: 'FF1F4E79' } };
  ws.getCell('B5').alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(5).height = 32;

  // === 报价单编号 / 日期 ===
  ws.getCell('B7').value = 'Quotation No.:';
  ws.getCell('B7').font = { name: 'Arial', size: 10, bold: true };
  ws.mergeCells('C7:D7');
  ws.getCell('C7').value = 'JSS-20261013-SA001';
  ws.getCell('C7').font = { name: 'Arial', size: 10 };

  ws.getCell('E7').value = 'Date:';
  ws.getCell('E7').font = { name: 'Arial', size: 10, bold: true };
  ws.getCell('E7').alignment = { horizontal: 'right' };
  ws.getCell('F7').value = '2026-10-13';
  ws.getCell('F7').font = { name: 'Arial', size: 10 };
  ws.mergeCells('F7:G7');

  ws.getCell('B8').value = 'Valid Until:';
  ws.getCell('B8').font = { name: 'Arial', size: 10, bold: true };
  ws.mergeCells('C8:D8');
  ws.getCell('C8').value = '2026-11-12';
  ws.getCell('C8').font = { name: 'Arial', size: 10 };

  ws.getCell('E8').value = 'Currency:';
  ws.getCell('E8').font = { name: 'Arial', size: 10, bold: true };
  ws.getCell('E8').alignment = { horizontal: 'right' };
  ws.getCell('F8').value = 'USD (Exchange Rate: 6.70)';
  ws.getCell('F8').font = { name: 'Arial', size: 10 };
  ws.mergeCells('F8:G8');

  // === TO / FROM 分列 ===
  // FROM（左侧）
  ws.mergeCells('B10:D10');
  ws.getCell('B10').value = 'FROM (Supplier):';
  ws.getCell('B10').font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('B10').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell('B10').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
  ws.getRow(10).height = 22;

  ws.mergeCells('E10:G10');
  ws.getCell('E10').value = 'TO (Customer):';
  ws.getCell('E10').font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell('E10').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell('E10').alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };

  // From 内容
  const fromInfo = [
    'Company: Changzhou JSS Motor Co., Ltd.',
    'Address: Changzhou, Jiangsu, China',
    'Contact: Sales Department',
    'Tel: +86-xxx-xxxx-xxxx',
    'Email: info@jss-motor.com',
  ];
  fromInfo.forEach((line, i) => {
    ws.mergeCells(`B${11 + i}:D${11 + i}`);
    const cell = ws.getCell(`B${11 + i}`);
    cell.value = line;
    cell.font = { name: 'Arial', size: 10 };
    cell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
  });

  // To 内容
  const toInfo = [
    { label: 'Company: Saeed Bright Company' },
    { label: 'Address: Afghanistan, Kabul' },
    { label: 'Ship To: Yiwu City, China' },
    { label: 'Contact: Samiullah Samim' },
    { label: 'Tel: 93798289276' },
    { label: 'Email: samiullahsamim735@gmail.com' },
  ];
  toInfo.forEach((line, i) => {
    ws.mergeCells(`E${11 + i}:G${11 + i}`);
    const cell = ws.getCell(`E${11 + i}`);
    cell.value = line.label;
    cell.font = { name: 'Arial', size: 10 };
    cell.alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
  });

  // === Product Table Header ===
  const tableStartRow = 18;
  const headers = ['NO.', 'Description', 'Model', 'Qty', 'Unit Price (USD)', 'Total (USD)'];
  headers.forEach((h, i) => {
    const col = String.fromCharCode(66 + i); // B=66
    const cell = ws.getCell(`${col}${tableStartRow}`);
    cell.value = h;
    cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = allBorders;
  });
  ws.getRow(tableStartRow).height = 24;

  // === Product Rows ===
  const products = [
    {
      no: 1,
      desc: '9kW Air-Cooled Automatic Tool Change (ATC) Spindle Motor, ISO30, 4 Bearings (Chinese Brand)',
      model: 'GDL70-24Z/9.0',
      qty: 1,
      unit: 1940.30,
      note: 'EXW Price, Tax Excluded',
    },
    {
      no: 2,
      desc: '9kW Air-Cooled Automatic Tool Change (ATC) Spindle Motor, ISO30, 4 Bearings (NSK Imported)',
      model: 'GDL70-24Z/9.0',
      qty: 1,
      unit: 2231.34,
      note: 'EXW Price, Tax Excluded',
    },
    {
      no: 3,
      desc: '12kW Air-Cooled Automatic Tool Change (ATC) Spindle Motor, ISO30, 4 Bearings (Chinese Brand)',
      model: 'TBD',
      qty: 1,
      unit: null,
      note: 'Price on Request - Quotation Pending',
    },
  ];

  products.forEach((p, i) => {
    const r = tableStartRow + 1 + i;
    ws.getCell(`B${r}`).value = p.no;
    ws.getCell(`C${r}`).value = p.desc;
    ws.getCell(`D${r}`).value = p.model;
    ws.getCell(`E${r}`).value = p.qty;
    if (p.unit !== null) {
      ws.getCell(`F${r}`).value = p.unit;
      ws.getCell(`G${r}`).value = p.unit * p.qty;
      ws.getCell(`F${r}`).numFmt = '"$"#,##0.00';
      ws.getCell(`G${r}`).numFmt = '"$"#,##0.00';
    } else {
      ws.getCell(`F${r}`).value = 'TBD';
      ws.getCell(`G${r}`).value = 'TBD';
    }

    // 样式
    ['B', 'C', 'D', 'E', 'F', 'G'].forEach((col) => {
      const cell = ws.getCell(`${col}${r}`);
      cell.font = { name: 'Arial', size: 10 };
      cell.border = allBorders;
      if (col === 'B' || col === 'E') {
        cell.alignment = { horizontal: 'center', vertical: 'middle' };
      } else if (col === 'F' || col === 'G') {
        cell.alignment = { horizontal: 'right', vertical: 'middle' };
      } else {
        cell.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true, indent: 1 };
      }
    });
    ws.getRow(r).height = 36;
  });

  // === Total Row ===
  const totalRow = tableStartRow + 1 + products.length;
  ws.mergeCells(`B${totalRow}:E${totalRow}`);
  const totalLabel = ws.getCell(`B${totalRow}`);
  totalLabel.value = 'TOTAL (USD, Tax Excluded):';
  totalLabel.font = { name: 'Arial', size: 11, bold: true };
  totalLabel.alignment = { horizontal: 'right', vertical: 'middle' };
  totalLabel.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE7E6E6' } };
  totalLabel.border = allBorders;

  ws.mergeCells(`F${totalRow}:G${totalRow}`);
  const totalVal = ws.getCell(`F${totalRow}`);
  // 9kW x2 + 12kW未报价 = 4171.64
  totalVal.value = 4171.64;
  totalVal.numFmt = '"$"#,##0.00';
  totalVal.font = { name: 'Arial', size: 12, bold: true, color: { argb: 'FFC00000' } };
  totalVal.alignment = { horizontal: 'right', vertical: 'middle' };
  totalVal.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF2CC' } };
  totalVal.border = allBorders;
  ws.getRow(totalRow).height = 26;

  // === 备注 / Terms ===
  const termsStart = totalRow + 2;
  ws.mergeCells(`B${termsStart}:G${termsStart}`);
  ws.getCell(`B${termsStart}`).value = 'TERMS & CONDITIONS';
  ws.getCell(`B${termsStart}`).font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getCell(`B${termsStart}`).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F4E79' } };
  ws.getCell(`B${termsStart}`).alignment = { horizontal: 'left', vertical: 'middle', indent: 1 };
  ws.getRow(termsStart).height = 22;

  const terms = [
    '1. Price Term: EXW Yiwu, China (FOB Ningbo available upon request)',
    '2. Payment Term: 30% T/T deposit, 70% balance before shipment',
    '3. Delivery Time: 15-20 working days after receiving deposit',
    '4. Validity: 30 days from the date of this quotation',
    '5. Packing: Standard export carton with foam protection',
    '6. Warranty: 12 months (bearings excluded)',
    '7. The 12kW ATC spindle price is pending factory confirmation; will be provided within 24 hours.',
    '8. Chinese-brand bearings: 7-series domestic (Yuzhou/Leitte); Imported NSK bearings available at extra cost.',
  ];

  terms.forEach((t, i) => {
    ws.mergeCells(`B${termsStart + 1 + i}:G${termsStart + 1 + i}`);
    const cell = ws.getCell(`B${termsStart + 1 + i}`);
    cell.value = t;
    cell.font = { name: 'Arial', size: 9 };
    cell.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true, indent: 1 };
    ws.getRow(termsStart + 1 + i).height = 18;
  });

  // === Footer ===
  const footerRow = termsStart + 1 + terms.length + 1;
  ws.mergeCells(`B${footerRow}:G${footerRow}`);
  ws.getCell(`B${footerRow}`).value = 'We look forward to your favorable reply. For any questions, please feel free to contact us.';
  ws.getCell(`B${footerRow}`).font = { name: 'Arial', size: 10, italic: true };
  ws.getCell(`B${footerRow}`).alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(footerRow).height = 24;

  const footerRow2 = footerRow + 1;
  ws.mergeCells(`B${footerRow2}:G${footerRow2}`);
  ws.getCell(`B${footerRow2}`).value = 'CHANGZHOU JSS MOTOR CO., LTD.  |  Page 1 of 1';
  ws.getCell(`B${footerRow2}`).font = { name: 'Arial', size: 8, color: { argb: 'FF888888' } };
  ws.getCell(`B${footerRow2}`).alignment = { horizontal: 'center', vertical: 'middle' };

  // 保存
  const outPath = 'C:/Users/Administrator/Coze/Drive/扣子/Saeed_Bright_Quotation_20261013.xlsx';
  await wb.xlsx.writeFile(outPath);
  console.log('Saved:', outPath);
}

main().catch(console.error);
