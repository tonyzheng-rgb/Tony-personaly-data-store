# 上传到 GitHub

三种方式，按省事程度排序。**方式一最简单，30 秒搞定。**

---

## 方式一：网页拖拽上传（推荐，不用装任何工具）

1. **下载并解压**本仓库压缩包，得到 `jss-quote-agent/` 文件夹
2. 打开 https://github.com/new
   - Repository name：`jss-quote-agent`
   - 可见性：Public 或 Private（**含供应商报价和公司全名，建议选 Private**）
   - ⚠️ **不要**勾选 Add a README file / .gitignore / License（会把文件补进来，冲突）
   - 点 **Create repository**
3. 进入新仓库页面 → 右上角 **Add file** → **Upload files**
4. 把解压出来的**整个 `jss-quote-agent` 文件夹**拖到页面上（注意是拖文件夹，不是拖里面的文件）
5. 底部填 commit message → **Commit changes**

搞定。文件结构会保留：`agent/`、`skills/`、`scripts/`、`docs/`。

> 浏览器限制单次最多 100 个文件，本仓库 35 个，没问题。

---

## 方式二：命令行一条龙（推荐给会用 git 的）

### Windows

双击 **`push.bat`** 即可，它会引导你完成登录、建仓、推送。

### macOS / Linux

```bash
cd jss-quote-agent
bash upload.sh              # 交互式，会让你选公开/私有
bash upload.sh --private    # 直接建私有仓库
```

脚本会自动：检测 git/CLI → 初始化仓库 → 提交 → 选可见性 → 创建仓库 → 推送。

---

## 方式三：设备码授权（不用装 GitHub CLI）

```bash
cd jss-quote-agent
bash device_flow.sh
```

脚本会申请一个一次性设备码并打印出来，你在 https://github.com/login/device 输入即可。
**15 分钟过期会自动换新码**，不用赶时间。

---

## 方式四：手动敲命令

```bash
cd jss-quote-agent

git init -b main
git add -A
git commit -m "feat: JSS 电机出口报价 Agent 配置与 jss-quoting 技能包"

# 登录（二选一）
gh auth login                    # 如果装了 GitHub CLI
# 或
git config --global credential.helper store   # 之后按提示输入 PAT

# 建仓并推送
gh repo create jss-quote-agent --private --source=. --push
# 没有 gh 的话，先在网页建空仓库，再：
git remote add origin https://github.com/<你的用户名>/jss-quote-agent.git
git push -u origin main
```

---

## 推完之后

仓库里建议补一个 `.gitignore`（已包含），确保这些不会上去：

```
private-data/      # 你的个人待办数据
*.xls  *.xlsx      # 原始报价表（含成本，体积大）
node_modules/
output/
```

已经在 `.gitignore` 里配好了，不用动。

---

## 常见问题

**Q：网页上传后文件结构乱了？**
A：拖拽时把整个文件夹拖进去，而不是只拖 `jss-quote-agent` 里面的文件。

**Q：三种脚本怎么选？**
A：`upload.sh` 最全（能选公开/私有，推荐）；`push.bat` 是 Windows 双击版；`device_flow.sh` 是没装 GitHub CLI 时的备选。

**Q：想改成公开仓库？**
A：`agent/memory/project/` 里是供应商报价表和公司全名。公开前建议先脱敏——把具体价格替换成 `【见原始报价表】`，或者干脆只上传 `skills/` 和 `scripts/` 两个目录。

**Q：这个仓库能干嘛？**
A：见 `README.md`。核心是 `skills/jss-quoting/` 这个技能包——把它拷到任何支持 Skill 的 Agent 里，就能获得同一套报价能力（含税规则、数量档位、3A225 出口合规判定、报价单生成）。
