# JSS Quote Agent

电机 / 变频器 / 雕刻机配件行业的出口报价 Agent 配置与可安装技能。包含系统提示词、行为规则、报价知识库、报价单生成脚本，以及一个符合 Skill 规范的 `jss-quoting` 技能包。

可用于：备份与版本管理、在扣子或其他 Agent 平台重建同样的报价能力、把报价工作流直接装进任意支持 Skill 的助手。

---

## 目录结构

```
jss-quote-agent/
├── README.md
├── LICENSE                            # MIT
├── .gitignore
├── agent/                             # Agent 本体配置
│   ├── system_prompt.md               # 系统提示词模板
│   ├── rules.md                       # 业务规则（含税/汇率/档位/交期/付款）
│   └── memory/
│       ├── SOUL.md                    # 角色性格
│       ├── USER.md                    # 业务方画像
│       ├── MEMORY.md                  # 长期规则 + 状态锚点
│       ├── index.json                 # 记忆索引
│       └── project/                   # 12 个品类的报价知识库
├── skills/
│   └── jss-quoting/
│       ├── SKILL.md                   # 可安装技能主文件
│       └── references/
│           ├── quoting-knowledge.md   # 报价速查表
│           └── 3a225-compliance.md    # 出口管制合规
├── scripts/                           # 报价单生成脚本
│   ├── gen_atc_quote.js               # 中文报价单 xlsx
│   ├── gen_saeed_quote.js             # 英文报价单 xlsx
│   ├── gen_mia.js / gen_mia2.js       # MIA 格式报价
│   ├── gen_pdf_en.cjs                 # 英文报价单 PDF
│   ├── gen_pdf_puppeteer.cjs          # HTML→PDF（需本机浏览器）
│   ├── gen_mujtahid_pdfkit.cjs        # pdfkit 绘图范式（无浏览器依赖）
│   ├── gen_chart.js                   # 转速-转矩曲线
│   ├── daily_market_chart.py          # 每日行情图表（汇率/金油铜/A股美股）
│   └── quote_calc.py                  # 报价换算
├── docs/
│   └── 迁移指南.md
└── private-data/                      # 个人待办等私有数据（.gitignore 已排除）
```

---

## 三种使用方式

### A. 装成技能（推荐）
把 `skills/jss-quoting/` 整个目录放到目标 Agent 的技能目录，或直接让 Agent 读取 `SKILL.md`。
所有价格规则、型号速查、合规边界都在 `SKILL.md` + `references/` 里，自带上下文。

### B. 在扣子重建 Agent
1. 新建 Bot，把 `agent/system_prompt.md` 粘到「人设与回复逻辑」
2. 把 `agent/memory/project/` 下的 Markdown 上传为知识库
3. 把 `agent/rules.md` 追加到系统提示词
4. 安装 `excel_master` 等必要的技能

### C. 本地 LLM + RAG
1. `agent/memory/project/` 作为知识库
2. `agent/system_prompt.md` + `agent/rules.md` 作为 system prompt
3. `scripts/` 里的脚本生成报价单

---

## 报价规则速览

| 项 | 规则 |
|---|---|
| 默认价 | 未税 |
| 含税 | × 1.10（拖链 × 1.13） |
| 出口汇率 | 6.67（按当日中间价校准） |
| 出口报价档位 | 中批量 50 台左右；1-10 台 +5%；100 台以上另谈 |
| 闭环转矩 | 理论转矩 = 开环 × 1.10 |
| NMRV 减速机 | 已含税含运 |

---

## 报价单生成

```bash
npm install exceljs xlsx sharp pdfkit puppeteer

node scripts/gen_atc_quote.js        # 中文 xlsx
node scripts/gen_saeed_quote.js      # 英文 xlsx
node scripts/gen_mujtahid_pdfkit.cjs # 英文 PDF（跨平台，推荐）
node scripts/gen_chart.js            # 转速-转矩曲线
```

> PDF 生成优先用 `pdfkit`：纯 JS 绘制，不依赖本机浏览器，Linux 环境可用。
> `puppeteer` 方案需要本机有 Chrome / Edge。

---

## 更新数据

拿到新的 Excel 报价表后：

1. 用 `xlsx` 库按 sheet 名读取，生成对应的 Markdown 知识库
2. 更新 `agent/memory/project/` 下对应文件
3. 同步 `agent/rules.md` 与 `agent/memory/MEMORY.md` 的规则与锚点
4. 更新 `agent/memory/index.json`（`file_name` / `category` / `summary` / `tags` / `importance` / 时间戳）
5. 若规则有变，同步更新 `skills/jss-quoting/SKILL.md` 与 `references/`

---

## 免责声明

- 本仓库中的价格数据来自 2026 年 3 月 30 日版对外销售价表，**仅供内部参考，实际成交以当期报价为准**
- 报价、汇率、含税口径在每次使用前应与当期政策校准
- 不包含任何客户个人信息、API 密钥或平台凭证
